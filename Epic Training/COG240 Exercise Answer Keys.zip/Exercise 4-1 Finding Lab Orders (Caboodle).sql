--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT patdim.Name "Patient",
       provdim.Name "Authorizing Provider",
       pof.ProcedureOrderEpicId "Order ID",
       orderdate.DisplayString "Date Ordered"
  FROM ProcedureOrderFact pof
    INNER JOIN ProcedureDim procdim
      ON pof.ProcedureDurableKey = procdim.DurableKey
		AND procdim.IsCurrent = 1
    INNER JOIN ProviderDim provdim
      ON pof.AuthorizedByProviderDurableKey = provdim.DurableKey
		AND provdim.IsCurrent = 1
    INNER JOIN PatientDim patdim
      ON pof.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DateDim orderdate
      ON pof.OrderedDateKey = orderdate.DateKey
  WHERE	procdim.Code = 'LAB90' --Hemoglobin A1c test
  ORDER BY "Authorizing Provider"
         , "Patient"