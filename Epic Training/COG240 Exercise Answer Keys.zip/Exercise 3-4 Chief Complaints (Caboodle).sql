--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

--Outpatient

SELECT patdim.Name "Patient Name",
       patdim.PrimaryMrn "Patient MRN"
  FROM EncounterFact encfact
    INNER JOIN ChiefComplaintBridge reasonbridge
      ON encfact.ChiefComplaintComboKey = reasonbridge.ChiefComplaintComboKey
    INNER JOIN PatientDim patdim
      ON encfact.PatientDurableKey = patdim.DurableKey
	    AND patdim.IsCurrent = 1
  WHERE reasonbridge.Name = 'Chest Pain'
    AND encfact.Type = 'Office Visit'

--Emergency

SELECT patdim.Name "Patient Name",
       patdim.PrimaryMrn "Patient MRN"
  FROM EdVisitFact edfact
    INNER JOIN ChiefComplaintBridge reasonbridge
      ON edfact.ChiefComplaintComboKey = reasonbridge.ChiefComplaintComboKey
    INNER JOIN PatientDim patdim
      ON edfact.PatientDurableKey = patdim.DurableKey
	    AND patdim.IsCurrent = 1
  WHERE reasonbridge.Name = 'Chest Pain'