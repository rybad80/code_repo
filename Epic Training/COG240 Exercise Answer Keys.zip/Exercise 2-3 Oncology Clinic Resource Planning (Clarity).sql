--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT YEAR( enc.CONTACT_DATE ) "Year",
       MONTH( enc.CONTACT_DATE ) "Month",
       COUNT( * ) "Count of Appointments"
  FROM EPISODE epi
    INNER JOIN EPISODE_LINK epienc
      ON epi.EPISODE_ID = epienc.EPISODE_ID
    INNER JOIN PAT_ENC enc
      ON epienc.PAT_ENC_CSN_ID = enc.PAT_ENC_CSN_ID
  WHERE	epi.SUM_BLK_TYPE_ID = 10 --Oncology episode type
	AND enc.ENC_TYPE_C = '2508' --Infusion encounter type
	AND enc.DEPARTMENT_ID = 10501201 --Specified department
  GROUP BY YEAR( enc.CONTACT_DATE ),
           MONTH( enc.CONTACT_DATE )
  ORDER BY "Year",
           "Month"