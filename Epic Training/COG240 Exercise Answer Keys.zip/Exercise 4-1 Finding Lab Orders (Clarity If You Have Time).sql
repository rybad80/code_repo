--� 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT pat.PAT_NAME "Patient",
       ser.PROV_NAME "Authorizing Provider",
       ord.ORDER_PROC_ID "Order ID",
       ord.ORDER_INST "Date Ordered"
	   eap.PROC_NAME "Procedure Ordered"
  FROM ORDER_PROC ord
	INNER JOIN CLARITY_EAP eap
	  ON ord.PROC_ID = eap.PROC_ID
    INNER JOIN CLARITY_SER ser
      ON ord.AUTHRZING_PROV_ID = ser.PROV_ID
    INNER JOIN PATIENT pat
      ON ord.PAT_ID = pat.PAT_ID

--If You Have Time Grouper Addition
    INNER JOIN GROUPER_COMPILED_REC_LIST grouper
	  ON eap.PROC_ID = grouper.GROUPER_RECORDS_NUMERIC_ID

  WHERE	grouper.BASE_GROUPER_ID = '2100000462'   --Using the grouper ID instead of the Procedure Code
        AND grouper.COMPILED_CONTEXT = 'EAP' 
  ORDER BY "Authorizing Provider"	
         , "Patient"