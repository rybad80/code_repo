--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug
SELECT notefact.ClinicalNoteKey "H&P Note",
       patdim.Name "Patient",
       empdim.Name "Note Author"
  FROM ClinicalNoteFact notefact
    INNER JOIN PatientDim patdim
      ON notefact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN EmployeeDim empdim
      ON notefact.AuthoringEmployeeDurableKey = empdim.DurableKey
		AND empdim.IsCurrent = 1
  WHERE notefact.Type = 'H&P'
    AND notefact.Status = 'Cosign Needed'