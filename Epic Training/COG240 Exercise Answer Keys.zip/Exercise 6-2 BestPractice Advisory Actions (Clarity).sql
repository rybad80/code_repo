--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT emp.USER_ID "User ID",
       emp.NAME "User Name",
       alt.ALERT_DESC "Alert Description",
       ah.ALT_ACTION_INST "Time Action Taken",
       act.NAME "Action Taken"
  FROM ALERT alt
    INNER JOIN ALT_HISTORY ah
      ON alt.ALT_ID = ah.ALT_ID
    INNER JOIN CLARITY_EMP emp
      ON ah.USER_ID = emp.USER_ID
    LEFT OUTER JOIN ALT_COM_ACTION aca
      ON ah.ALT_CSN_ID = aca.ALT_CSN_ID
	LEFT OUTER JOIN ZC_ALT_ACTION_TAKE act
      ON aca.ACTION_TAKEN_C = act.ALT_ACTION_TAKEN_C
  WHERE	alt.GENERAL_ALT_TYPE_C = 1 --BestPractice Advisory
    AND ah.ALT_ACTION_INST >= '01-01-2016' 
    AND ah.ALT_ACTION_INST <  '01-01-2017'
  ORDER BY "User ID",
           "Time Action Taken"