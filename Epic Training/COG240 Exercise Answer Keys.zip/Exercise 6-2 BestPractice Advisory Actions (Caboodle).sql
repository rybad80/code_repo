--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug
SELECT empdim.EmployeeEpicId "User ID",
       empdim.Name "User Name",
       build.Name "Alert Description",
       bpa.TriggerInstant "Time Action Taken",
       action.ActionTaken "Action Taken"
  FROM BpaFact bpa
    INNER JOIN BpaBuildDim build
      ON bpa.BpaBuildKey = build.BpaBuildKey
	INNER JOIN EmployeeDim empdim
      ON bpa.EmployeeDurableKey = empdim.DurableKey
		AND empdim.IsCurrent = 1
	LEFT OUTER JOIN BpaActionTakenFact action
      ON bpa.BpaKey = action.BpaKey
  WHERE bpa.TriggerInstant >= '01-01-2016' 
    AND bpa.TriggerInstant <  '01-01-2017'
  ORDER BY "User ID",
           "Time Action Taken"