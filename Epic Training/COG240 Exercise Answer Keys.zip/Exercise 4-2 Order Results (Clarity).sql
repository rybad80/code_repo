--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT ser.PROV_NAME "Authorizing Provider",
       pat.PAT_NAME "Patient",
       res.RESULT_DATE "Result Date",
       res.ORD_NUM_VALUE "Test Result"
  FROM ORDER_PROC op
    INNER JOIN ORDER_RESULTS res
      ON op.ORDER_PROC_ID = res.ORDER_PROC_ID
    INNER JOIN CLARITY_SER ser
      ON op.AUTHRZING_PROV_ID = ser.PROV_ID
    INNER JOIN PATIENT pat
      ON op.PAT_ID = pat.PAT_ID
  WHERE	res.COMPONENT_ID IN (1558024,1526664) --Hemoglobin A1c test
    AND res.ORD_NUM_VALUE >= 7
    AND res.ORD_NUM_VALUE <> 9999999
  ORDER BY pat.PAT_ID,
           res.RESULT_DATE
