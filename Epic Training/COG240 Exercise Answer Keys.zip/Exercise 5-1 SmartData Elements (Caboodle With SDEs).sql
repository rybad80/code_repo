--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug
SELECT encfact.EncounterEpicCsn "Encounter CSN",
       encdate.DisplayString "Encounter Date",
       patdim.Name "Patient Name",
       diagdim.Name "Primary Diagnosis",
	   --Adding SDE columns
	   attdim.Name "Dilation Question",
       eavd.Value "Dilation Answer"
  FROM EncounterFact encfact
    INNER JOIN PatientDim patdim
      ON encfact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DiagnosisDim diagdim
      ON encfact.PrimaryDiagnosisKey = diagdim.DiagnosisKey
    INNER JOIN DepartmentDim depdim
      ON encfact.DepartmentKey = depdim.DepartmentKey
    INNER JOIN DateDim encdate
      ON encfact.DateKey = encdate.DateKey
	--Adding SDE tables
	INNER JOIN EncounterAttributeValueDim eavd
	  ON encfact.EncounterKey = eavd.EncounterKey
		AND eavd.IsCurrent = 1
	INNER JOIN AttributeDim attdim
	  ON eavd.AttributeKey = attdim.AttributeKey
  WHERE depdim.DepartmentEpicId = '10501103'
    AND encdate.DateValue >= '1/1/2008'
    AND encdate.DateValue < '1/1/2018'
	--Adding SDE conditions
	AND attdim.SmartDataElementEpicId IN ( 'EPIC#OPH451', 'EPIC#OPH452', 'EPIC#OPH453' )
  ORDER BY "Encounter CSN"