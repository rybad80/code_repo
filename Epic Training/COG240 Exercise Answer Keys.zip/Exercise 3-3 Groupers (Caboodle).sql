--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT ept.Name "Patient",
       ept.PrimaryMrn "Primary MRN",
       noteddate.DisplayString "Problem Noted Date",
       edg.Name "Diagnosis"	   
FROM ProblemListFact lpl
INNER JOIN DiagnosisSetDim grouper
	  ON lpl.DiagnosisKey = grouper.DiagnosisKey
INNER JOIN PatientDim ept
	ON lpl.PatientDurableKey = ept.DurableKey and ept.IsCurrent = 1
INNER JOIN DiagnosisDim edg
	ON edg.DiagnosisKey = lpl.DiagnosisKey
INNER JOIN DateDim noteddate
	ON noteddate.DateKey = lpl.StartDateKey
WHERE grouper.ValueSetEpicId = '1766006'
      AND lpl.Status = 'Active'


