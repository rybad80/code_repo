--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT pat.PAT_MRN_ID "Patient MRN",
       dmd.OFF_VIS_LAST_DT "Date of Last Office Visit",
       dmd.BP_SYS_LAST "Last Systolic BP",
       dmd.BP_DIA_LAST "Last Diastolic BP",
       dmd.HBA1C_LAST "Last Hemoglobin A1c",
       dmd.CUR_PCP_PROV_ID "Current General PCP ID",
       ser.PROV_NAME "Current General PCP Name"
  FROM DM_DIABETES dmd
    INNER JOIN PATIENT pat
      ON dmd.PAT_ID = pat.PAT_ID
    INNER JOIN CLARITY_SER ser
      ON dmd.CUR_PCP_PROV_ID = ser.PROV_ID
  WHERE dmd.REGISTRY_STATUS_C = 1 --Active
  ORDER BY "Current General PCP Name"