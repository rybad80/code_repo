--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT visfact.EncounterEpicCsn "CSN",
	   visdate.DisplayString "EncounterDate",
       diagdim.DiagnosisEpicId "Diagnosis ID",
       diagdim.Name "DiagnosisName"
  FROM DiagnosisEventFact diagfact
    INNER JOIN VisitFact visfact
      ON diagfact.EncounterKey = visfact.EncounterKey
    INNER JOIN DiagnosisDim diagdim
      ON diagfact.DiagnosisKey = diagdim.DiagnosisKey
    INNER JOIN DateDim visdate
      ON visfact.EncounterDateKey = visdate.DateKey
  WHERE diagfact.Type = 'Encounter Diagnosis'
    AND visfact.EncounterType = 'Office Visit'
