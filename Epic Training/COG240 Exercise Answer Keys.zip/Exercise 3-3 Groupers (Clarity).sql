--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT ept.PAT_NAME "Patient",
       ept.PAT_MRN_ID "Primary MRN",
       lpl.NOTED_DATE "Problem Noted Date",
	   edg.DX_NAME "Diagnosis"
FROM PROBLEM_LIST lpl
INNER JOIN GROUPER_COMPILED_REC_LIST grouper
	ON lpl.DX_ID = grouper.GROUPER_RECORDS_NUMERIC_ID
INNER JOIN CLARITY_EDG edg
	ON lpl.DX_ID = edg.DX_ID
INNER JOIN PATIENT ept
	ON ept.PAT_ID = lpl.PAT_ID
WHERE lpl.PROBLEM_STATUS_C = 1  --Active
     AND grouper.BASE_GROUPER_ID = '1766006' --The NHSN Diabetes Grouper
	 AND grouper.COMPILED_CONTEXT = 'EDG' --Compiled for EDG

