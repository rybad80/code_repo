--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT erx.NAME "Medication",
       COUNT( mar.ORDER_MED_ID ) "Given Count"
  FROM MAR_ADMIN_INFO mar
    INNER JOIN ORDER_MEDINFO omed
      ON mar.ORDER_MED_ID = omed.ORDER_MED_ID
    INNER JOIN CLARITY_MEDICATION erx
      ON omed.DISPENSABLE_MED_ID = erx.MEDICATION_ID
  WHERE	mar.TAKEN_TIME >= '1/1/2017'
    AND mar.TAKEN_TIME < '1/1/2018' 
    AND mar.MAR_ACTION_C IN ( 1, 6 ) --1 is given, 6 is new bag
  GROUP BY erx.MEDICATION_ID, erx.NAME
  ORDER BY "Given Count" DESC,
           "Medication"