--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT enc.PAT_ENC_CSN_ID "CSN",
       pat.PAT_NAME "Patient",
       pcp.PROV_NAME "PCP",
       encprov.PROV_NAME "Encounter Provider"
  FROM PAT_ENC enc
    INNER JOIN PATIENT pat
      ON enc.PAT_ID = pat.PAT_ID
    INNER JOIN CLARITY_SER encprov
      ON enc.VISIT_PROV_ID = encprov.PROV_ID
	INNER JOIN CLARITY_SER pcp
      ON pat.CUR_PCP_PROV_ID = pcp.PROV_ID
  WHERE pat.CUR_PCP_PROV_ID <> encprov.PROV_ID
    AND enc.ENC_TYPE_C = '101' --Office Visit