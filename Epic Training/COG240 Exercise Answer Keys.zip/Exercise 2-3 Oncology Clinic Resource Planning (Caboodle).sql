--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT encdate.Year "Year",
       MAX( encdate.MonthName ) "Month",
       COUNT( * ) "Count of Appointments"
  FROM EpisodeFact epifact
    INNER JOIN EpisodeEncounterMappingFact mapfact
      ON epifact.EpisodeKey = mapfact.EpisodeKey
    INNER JOIN EncounterFact encfact
      ON mapfact.EncounterKey = encfact.EncounterKey
    INNER JOIN DepartmentDim depdim
      ON encfact.DepartmentKey = depdim.DepartmentKey
    INNER JOIN DateDim encdate
      ON encfact.DateKey = encdate.DateKey
  WHERE epifact.Type = 'Oncology Treatment'
    AND encfact.Type = 'Infusion'
    AND depdim.DepartmentEpicId = 10501201 --Specified department
  GROUP BY encdate.Year,
           encdate.MonthNumber
  ORDER BY encdate.Year,
           encdate.MonthNumber