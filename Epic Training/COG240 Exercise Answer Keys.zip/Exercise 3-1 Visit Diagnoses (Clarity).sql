--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT pe.PAT_ENC_CSN_ID "CSN",
	   pe.CONTACT_DATE "EncounterDate",
       diag.DX_ID "Diagnosis ID",
       edg.DX_NAME "DiagnosisName"
  FROM PAT_ENC_DX diag
    INNER JOIN PAT_ENC pe
      ON pe.PAT_ENC_CSN_ID = diag.PAT_ENC_CSN_ID
    INNER JOIN CLARITY_EDG edg
      ON diag.DX_ID = edg.DX_ID
  WHERE pe.ENC_TYPE_C = '101' --Office Visit