--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT dischdate.DisplayString "Discharge Date",
       patdim.Name "Patient Name",
       depdim.DepartmentName "Discharge Department",
       diagdim.Name "Unresolved Problem"
  FROM HospitalAdmissionFact hspadmfact
    INNER JOIN DateDim dischdate
      ON hspadmfact.DischargeDateKey = dischdate.DateKey
	INNER JOIN DiagnosisEventFact diagfact
	  ON diagfact.EncounterKey = hspadmfact.EncounterKey
    INNER JOIN PatientDim patdim
      ON hspadmfact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DiagnosisDim diagdim
      ON diagfact.DiagnosisKey = diagdim.DiagnosisKey
	INNER JOIN DepartmentDim depdim
      ON hspadmfact.DepartmentKey = depdim.DepartmentKey
  WHERE diagfact.Status = 'Active'
    AND hspadmfact.DischargeDateKey > 0 --Discharged
	AND diagfact.Type = 'Hospital Problem'