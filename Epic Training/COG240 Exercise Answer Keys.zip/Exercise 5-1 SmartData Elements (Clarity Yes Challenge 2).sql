--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT enc.PAT_ENC_CSN_ID "Encounter CSN",
       MAX( enc.CONTACT_DATE ) "Encounter Date",
       MAX( pat.PAT_NAME ) "Patient Name",
       MAX( edg.DX_NAME ) "Primary Diagnosis",
       MAX( CASE WHEN entity.ELEMENT_ID = 'EPIC#OPH451' THEN value.SMRTDTA_ELEM_VALUE ELSE NULL END ) "Dilated Eyes",
       MAX( CASE WHEN entity.ELEMENT_ID = 'EPIC#OPH452' THEN value.SMRTDTA_ELEM_VALUE ELSE NULL END ) "Dilation Time",
       MAX( CASE WHEN entity.ELEMENT_ID = 'EPIC#OPH453' THEN value.SMRTDTA_ELEM_VALUE ELSE NULL END ) "Dilation Medication"
  FROM PAT_ENC enc
    INNER JOIN PATIENT pat
      ON enc.PAT_ID = pat.PAT_ID
    LEFT OUTER JOIN PAT_ENC_DX encdx
      ON enc.PAT_ENC_CSN_ID = encdx.PAT_ENC_CSN_ID
        AND encdx.PRIMARY_DX_YN = 'Y'
    LEFT OUTER JOIN CLARITY_EDG edg
      ON encdx.DX_ID = edg.DX_ID
    LEFT OUTER JOIN SMRTDTA_ELEM_DATA entity
      ON enc.PAT_ENC_CSN_ID = entity.CONTACT_SERIAL_NUM
        AND entity.CONTEXT_NAME = 'ENCOUNTER'
    LEFT OUTER JOIN SMRTDTA_ELEM_VALUE value
      ON entity.HLV_ID = value.HLV_ID
    LEFT OUTER JOIN CLARITY_CONCEPT attribute
      ON entity.ELEMENT_ID = attribute.CONCEPT_ID
  WHERE enc.DEPARTMENT_ID = 10501103
    AND enc.CONTACT_DATE >= '1/1/2008'
    AND enc.CONTACT_DATE < '1/1/2018'
  GROUP BY enc.PAT_ENC_CSN_ID
