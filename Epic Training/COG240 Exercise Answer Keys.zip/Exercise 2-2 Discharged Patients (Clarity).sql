--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT dep.DEPARTMENT_ID "Department ID",
       dep.DEPARTMENT_NAME "Department Name",
	   peh.PAT_ENC_CSN_ID "CSN",
       peh.HOSP_DISCH_TIME "Discharge Date/Time",
       pat.PAT_MRN_ID "MRN",
       DATEDIFF( d, peh.INP_ADM_DATE, peh.HOSP_DISCH_TIME ) "Length of Stay"
  FROM PAT_ENC_HSP peh
    INNER JOIN CLARITY_DEP dep
      ON peh.DEPARTMENT_ID = dep.DEPARTMENT_ID
    INNER JOIN PATIENT pat
      ON peh.PAT_ID = pat.PAT_ID
  WHERE '2017-01-01' <= peh.HOSP_DISCH_TIME
    AND peh.HOSP_DISCH_TIME < '2018-01-01'
    AND peh.INP_ADM_DATE IS NOT NULL --Only hospital admissions
  ORDER BY dep.DEPARTMENT_ID  --sort by department