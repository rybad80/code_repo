--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT visfact.EncounterEpicCSN "CSN",
       patdim.Name "Patient",
       pcp.Name "PCP",
       visprov.Name "Encounter Provider"
  FROM VisitFact visfact
    INNER JOIN PatientDim patdim
      ON visfact.PatientDurableKey = patdim.DurableKey
	    AND patdim.IsCurrent = 1
    INNER JOIN ProviderDim visprov
      ON visfact.PrimaryVisitProviderDurableKey = visprov.DurableKey
	    AND visprov.IsCurrent = 1
    INNER JOIN ProviderDim pcp
      ON patdim.PrimaryCareProviderDurableKey = pcp.DurableKey
	    AND pcp.IsCurrent = 1
  WHERE patdim.PrimaryCareProviderDurableKey <> visfact.PrimaryVisitProviderDurableKey
    AND visfact.EncounterType = 'Office Visit'
    AND patdim.PrimaryCareProviderKey > 0  --Removes patient's without a PCP