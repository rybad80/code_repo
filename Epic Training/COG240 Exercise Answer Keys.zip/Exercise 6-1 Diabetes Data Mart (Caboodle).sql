--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug
SELECT patdim.PrimaryMrn "Patient MRN",
	   diab.OfficeVisitDate "Date of Last Office Visit",
	   diab.SystolicBloodPressureValue "Last Systolic BP",
	   diab.DiastolicBloodPressureValue "Last Diastolic BP",
	   diab.HbA1cValue "Last Hemoglobin A1c",
	   provdim.ProviderEpicId "Current General PCP ID",
	   provdim.Name "Current General PCP Name"
  FROM DiabetesRegistryDataMartX diab
    INNER JOIN PatientDim patdim
	  ON diab.PatientDurableKey = patdim.DurableKey
	    AND patdim.IsCurrent = 1
	INNER JOIN ProviderDim provdim
	  ON diab.PcpProviderDurableKey = provdim.DurableKey
	    AND provdim.IsCurrent = 1
  WHERE diab.IsMostRecent = 1
    AND diab.RegistryStatus = 'Active'
	AND patdim.Name NOT IN ('*Deleted', '*Unknown')
  ORDER BY "Current General PCP Name"