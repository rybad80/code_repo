--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT enc.PAT_ENC_CSN_ID "Encounter CSN",
       enc.CONTACT_DATE "Encounter Date",
       pat.PAT_NAME "Patient Name",
       edg.DX_NAME "Primary Diagnosis"



  FROM PAT_ENC enc
    INNER JOIN PATIENT pat
      ON enc.PAT_ID = pat.PAT_ID
    LEFT OUTER JOIN PAT_ENC_DX encdx
      ON enc.PAT_ENC_CSN_ID = encdx.PAT_ENC_CSN_ID
        AND encdx.PRIMARY_DX_YN = 'Y'
    LEFT OUTER JOIN CLARITY_EDG edg
      ON encdx.DX_ID = edg.DX_ID



	  



  WHERE enc.DEPARTMENT_ID = 10501103
    AND enc.CONTACT_DATE >= '1/1/2008'
    AND enc.CONTACT_DATE < '1/1/2018'



  ORDER BY "Encounter CSN"
