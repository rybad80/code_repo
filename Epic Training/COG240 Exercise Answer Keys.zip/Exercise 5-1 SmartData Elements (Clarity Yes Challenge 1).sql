--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT enc.PAT_ENC_CSN_ID "Encounter CSN",
       enc.CONTACT_DATE "Encounter Date",
       pat.PAT_NAME "Patient Name",
       edg.DX_NAME "Primary Diagnosis",
       attribute.NAME "Dilation Question",
       value.SMRTDTA_ELEM_VALUE "Dilation Answer"
  FROM PAT_ENC enc
    INNER JOIN PATIENT pat
      ON enc.PAT_ID = pat.PAT_ID
    LEFT OUTER JOIN PAT_ENC_DX encdx
      ON enc.PAT_ENC_CSN_ID = encdx.PAT_ENC_CSN_ID
        AND encdx.PRIMARY_DX_YN = 'Y'
    LEFT OUTER JOIN CLARITY_EDG edg
      ON encdx.DX_ID = edg.DX_ID
    LEFT OUTER JOIN SMRTDTA_ELEM_DATA entity
      ON enc.PAT_ENC_CSN_ID = entity.CONTACT_SERIAL_NUM
        AND entity.CONTEXT_NAME = 'ENCOUNTER'
        AND entity.ELEMENT_ID IN ( 'EPIC#OPH451', 'EPIC#OPH452', 'EPIC#OPH453' )
    LEFT OUTER JOIN SMRTDTA_ELEM_VALUE value
      ON entity.HLV_ID = value.HLV_ID
    LEFT OUTER JOIN CLARITY_CONCEPT attribute
      ON entity.ELEMENT_ID = attribute.CONCEPT_ID
  WHERE enc.DEPARTMENT_ID = 10501103
    AND enc.CONTACT_DATE >= '1/1/2008'
    AND enc.CONTACT_DATE < '1/1/2018'
  ORDER BY "Encounter CSN"
