--� 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT patdim.Name "Patient",
       provdim.Name "Authorizing Provider",
       pof.ProcedureOrderEpicId "Order ID",
       orderdate.DisplayString "Date Ordered",
	   procdim.Name "Procedure Ordered"
  FROM ProcedureOrderFact pof
    INNER JOIN ProcedureDim procdim
      ON pof.ProcedureDurableKey = procdim.DurableKey
		AND procdim.IsCurrent = 1
    INNER JOIN ProviderDim provdim
      ON pof.AuthorizedByProviderDurableKey = provdim.DurableKey
		AND provdim.IsCurrent = 1
    INNER JOIN PatientDim patdim
      ON pof.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DateDim orderdate
      ON pof.OrderedDateKey = orderdate.DateKey

--If You Have Time Grouper Addition
    INNER JOIN ProcedureSetDim grouper
	  ON procdim.DurableKey = grouper.ProcedureDurableKey

  WHERE	grouper.ValueSetEpicId = '2100000462'   --Using the grouper ID instead of the Procedure Code
  ORDER BY "Authorizing Provider"
         , "Patient"