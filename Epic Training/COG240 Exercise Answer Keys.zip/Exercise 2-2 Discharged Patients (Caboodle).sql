--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT depdim.DepartmentEpicId "Department ID",
       depdim.DepartmentName "Department Name",
	   hspfact.EncounterEpicCsn "CSN",
       dischdate.DisplayString "Discharge Date",
       patdim.PrimaryMrn "MRN",
       hspfact.InpatientLengthOfStayInDays "Length of Stay" --could also calculate yourself using DATEDIFF
  FROM HospitalAdmissionFact hspfact
    INNER JOIN DepartmentDim depdim
      ON hspfact.DepartmentKey = depdim.DepartmentKey
    INNER JOIN PatientDim patdim
      ON hspfact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
	INNER JOIN DateDim dischdate
      ON hspfact.DischargeDateKey = dischdate.DateKey
  WHERE dischdate.Year = 2017
  ORDER BY depdim.DepartmentEpicId  --Sort by department