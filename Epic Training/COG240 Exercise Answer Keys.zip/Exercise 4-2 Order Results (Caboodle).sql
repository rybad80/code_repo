--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT provdim.Name "Authorizing Provider",
       patdim.Name "Patient",
       resdate.DisplayString "Result Date",
       lcrf.Value "Test Result"
  FROM LabComponentResultFact lcrf
    INNER JOIN LabComponentDim compdim
      ON lcrf.LabComponentKey = compdim.LabComponentKey
	INNER JOIN ProviderDim provdim
      ON lcrf.AuthorizedByProviderDurableKey = provdim.DurableKey
		AND provdim.IsCurrent = 1
    INNER JOIN PatientDim patdim
      ON lcrf.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DateDim resdate
      ON lcrf.ResultDateKey = resdate.DateKey
  WHERE	compdim.LabComponentEpicId IN (1558024,1526664) --Hemoglobin A1c test
    AND lcrf.NumericValue >= 7
  ORDER BY patdim.PatientEpicId,
           resdate.DateValue