--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug
SELECT encfact.EncounterEpicCsn "Encounter CSN",
	   empdim.Name "User Name",
       flodim.DisplayName "Flowsheet Row Name",
       fsdfact.Value "Measurement Value",
       fsdfact.TakenInstant "Measurement Time",
       fsdfact.FirstDocumentedInstant "Documented Time"
  FROM FlowsheetValueFact fsdfact
    INNER JOIN FlowsheetRowDim flodim
      ON fsdfact.FlowsheetRowKey = flodim.FlowsheetRowKey
    INNER JOIN EncounterFact encfact
      ON fsdfact.EncounterKey = encfact.EncounterKey
        AND encfact.Type <> 'Surgery' --Exclude surgery encounters
    INNER JOIN EmployeeDim empdim
      ON fsdfact.TakenByEmployeeDurableKey = empdim.DurableKey
	    AND empdim.IsCurrent = 1
  WHERE fsdfact.TakenByEmployeeDurableKey = fsdfact.DocumentedByEmployeeDurableKey
    AND fsdfact.MinutesBetweenTakenAndFirstDoc >= 180   --Could also do a DATEADD/DATEDIFF	
	AND fsdfact.FirstDocumentedInstant > fsdfact.TakenInstant
    AND fsdfact.TakenInstant >= '1/1/2016'
    AND fsdfact.TakenInstant < '1/1/2017'
