--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT hno.NOTE_ID "H&P Note",
       MAX( pat.PAT_NAME ) "Patient",
       MAX( emp.NAME ) "Note Author"
  FROM NOTE_ENC_INFO nei
    INNER JOIN HNO_INFO hno
      ON nei.NOTE_ID = hno.NOTE_ID
    INNER JOIN PATIENT pat
      ON hno.PAT_ID = pat.PAT_ID
    INNER JOIN CLARITY_EMP emp
      ON nei.AUTHOR_USER_ID = emp.USER_ID
  WHERE hno.IP_NOTE_TYPE_C = '4' --4 = H&P
    AND nei.NOTE_STATUS_C = '9' --9 = Cosign Needed
  GROUP BY hno.NOTE_ID --In case more than one note contact needs a cosign
