--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT pat.PAT_NAME "Patient",
       ser.PROV_NAME "Authorizing Provider",
       ord.ORDER_PROC_ID "Order ID",
       ord.ORDER_INST "Date Ordered"
  FROM ORDER_PROC ord
	INNER JOIN CLARITY_EAP eap
	  ON ord.PROC_ID = eap.PROC_ID
    INNER JOIN CLARITY_SER ser
      ON ord.AUTHRZING_PROV_ID = ser.PROV_ID
    INNER JOIN PATIENT pat
      ON ord.PAT_ID = pat.PAT_ID
  WHERE	eap.PROC_CODE = 'LAB90' --Hemoglobin A1c test
  ORDER BY "Authorizing Provider"	
         , "Patient"