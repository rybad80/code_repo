--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

--Outpatient

SELECT pat.PAT_NAME "Patient Name",
       pat.PAT_MRN_ID "Patient MRN"
  FROM PAT_ENC enc
    INNER JOIN PATIENT pat
      ON enc.PAT_ID = pat.PAT_ID
    INNER JOIN PAT_ENC_RSN_VISIT rsn
      ON enc.PAT_ENC_CSN_ID = rsn.PAT_ENC_CSN_ID
    INNER JOIN CL_RSN_FOR_VISIT hrv
      ON rsn.ENC_REASON_ID = hrv.REASON_VISIT_ID
  WHERE hrv.REASON_VISIT_NAME = 'Chest Pain'
    AND enc.ENC_TYPE_C = '101' --Office Visit

--Emergency

SELECT pat.PAT_NAME "Patient Name",
       pat.PAT_MRN_ID "Patient MRN"
  FROM F_ED_ENCOUNTERS fee
    INNER JOIN PATIENT pat
      ON fee.PAT_ID = pat.PAT_ID
    INNER JOIN PAT_ENC_RSN_VISIT rsn
      ON fee.PAT_ENC_CSN_ID = rsn.PAT_ENC_CSN_ID
    INNER JOIN CL_RSN_FOR_VISIT hrv
      ON rsn.ENC_REASON_ID = hrv.REASON_VISIT_ID
  WHERE hrv.REASON_VISIT_NAME = 'Chest Pain'
