--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug
SELECT fee.PAT_ENC_CSN_ID "Encounter CSN",
	   pat.PAT_MRN_ID "Patient MRN",
	   fee.HOSPITAL_ACCOUNT_ID "Hospital Account Number",
	   DATEDIFF( n, iei_arrived.EVENT_TIME, iei_roomed.EVENT_TIME ) "Wait Until Rooming (Minutes)"
  FROM F_ED_ENCOUNTERS fee
    INNER JOIN PATIENT pat
      ON fee.PAT_ID = pat.PAT_ID
    INNER JOIN ED_IEV_PAT_INFO ipi
      ON fee.PAT_ENC_CSN_ID = ipi.PAT_CSN
    INNER JOIN ED_IEV_EVENT_INFO iei_arrived
      ON ipi.EVENT_ID = iei_arrived.EVENT_ID
	    AND iei_arrived.EVENT_STATUS_C IS NULL
		AND iei_arrived.EVENT_TYPE = '50' --Arrived Event
		AND iei_arrived.EVENT_DEPT_ID = '10101100' --EMH Emergency
	INNER JOIN ED_IEV_EVENT_INFO iei_roomed
      ON ipi.EVENT_ID = iei_roomed.EVENT_ID
	    AND iei_roomed.EVENT_STATUS_C IS NULL
		AND iei_roomed.EVENT_TYPE = '55' --Roomed Event
  WHERE fee.HOSPITAL_ADMISSION_DTTM >= '1/1/2016'
    AND fee.HOSPITAL_ADMISSION_DTTM < '1/1/2017'