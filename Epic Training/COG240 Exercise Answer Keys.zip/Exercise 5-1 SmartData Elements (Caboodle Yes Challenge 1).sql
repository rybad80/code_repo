--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug;

WITH eavd AS (SELECT * FROM EncounterAttributeValueDim WHERE IsCurrent = 1)
SELECT encfact.EncounterEpicCsn "Encounter CSN",
       encdate.DisplayString "Encounter Date",
       patdim.Name "Patient Name",
       diagdim.Name "Primary Diagnosis",
	   attdim.Name "Dilation Question",
       eavd.Value "Dilation Answer"
  FROM eavd
	INNER JOIN AttributeDim attdim
	  ON eavd.AttributeKey = attdim.AttributeKey
	  AND attdim.SmartDataElementEpicId IN ( 'EPIC#OPH451', 'EPIC#OPH452', 'EPIC#OPH453' )
    RIGHT OUTER JOIN EncounterFact encfact
	  ON encfact.EncounterKey = eavd.EncounterKey
    INNER JOIN PatientDim patdim
      ON encfact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DiagnosisDim diagdim
      ON encfact.PrimaryDiagnosisKey = diagdim.DiagnosisKey
    INNER JOIN DepartmentDim depdim
      ON encfact.DepartmentKey = depdim.DepartmentKey
    INNER JOIN DateDim encdate
      ON encfact.DateKey = encdate.DateKey
  WHERE depdim.DepartmentEpicId = '10501103'
    AND encdate.DateValue >= '1/1/2008'
    AND encdate.DateValue < '1/1/2018'
  ORDER BY "Encounter CSN"