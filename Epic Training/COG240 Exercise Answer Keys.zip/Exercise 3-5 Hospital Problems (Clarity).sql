--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT peh.HOSP_DISCH_TIME "Discharge Date",
       pat.PAT_NAME "Patient Name",
       dep.DEPARTMENT_NAME "Discharge Department",
       edg.DX_NAME "Unresolved Problem"
  FROM PAT_ENC_HSP peh
    INNER JOIN PAT_ENC_HOSP_PROB hp
	  ON hp.PAT_ENC_CSN_ID = peh.PAT_ENC_CSN_ID
    INNER JOIN PROBLEM_LIST pl
      ON hp.PROBLEM_LIST_ID = pl.PROBLEM_LIST_ID
    INNER JOIN PATIENT pat
      ON peh.PAT_ID = pat.PAT_ID
    INNER JOIN CLARITY_EDG edg
      ON pl.DX_ID = edg.DX_ID
	INNER JOIN CLARITY_DEP dep
      ON peh.DEPARTMENT_ID = dep.DEPARTMENT_ID
  WHERE pl.PROBLEM_STATUS_C = 1 --Active
    AND peh.HOSP_DISCH_TIME IS NOT NULL --Discharged
	AND peh.INP_ADM_DATE IS NOT NULL --Hospital Admissions
