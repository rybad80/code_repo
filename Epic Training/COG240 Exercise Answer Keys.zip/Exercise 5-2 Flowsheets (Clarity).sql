--© 2018-2023 Epic Systems Corporation. Confidential.
USE Clarity_Aug

SELECT enc.PAT_ENC_CSN_ID "Encounter CSN",
	   emp.NAME "User Name",
       flo.DISP_NAME "Flowsheet Row Name",
       fsd.MEAS_VALUE "Measurement Value",
       fsd.RECORDED_TIME "Measurement Time",
       fsd.ENTRY_TIME "Documented Time"
  FROM IP_FLWSHT_MEAS fsd
    INNER JOIN IP_FLO_GP_DATA flo
      ON fsd.FLO_MEAS_ID = flo.FLO_MEAS_ID
    INNER JOIN IP_FLWSHT_REC inp
      ON fsd.FSD_ID = inp.FSD_ID
    INNER JOIN PAT_ENC enc
      ON inp.INPATIENT_DATA_ID = enc.INPATIENT_DATA_ID
        AND enc.ENC_TYPE_C <> '51' --Exclude surgery encounters
    INNER JOIN CLARITY_EMP emp
      ON fsd.TAKEN_USER_ID = emp.USER_ID
  WHERE fsd.TAKEN_USER_ID = fsd.ENTRY_USER_ID
    AND DATEADD( hh, 3, fsd.RECORDED_TIME ) <= fsd.ENTRY_TIME
    AND fsd.RECORDED_TIME >= '1/1/2016'
    AND fsd.RECORDED_TIME < '1/1/2017'
