--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug

SELECT meddim.Name "Medication",
       COUNT( mar.MedicationAdministrationKey ) "Given Count"
  FROM MedicationAdministrationFact mar
    INNER JOIN MedicationDim meddim
      ON mar.MedicationKey = meddim.MedicationKey
    INNER JOIN DateDim admindate
      ON mar.AdministrationDateKey = admindate.DateKey
  WHERE	admindate.Year = 2017 
    AND mar.AdministrationAction IN ( 'Given', 'New Bag' )
  GROUP BY meddim.MedicationKey, meddim.Name
  ORDER BY "Given Count" DESC,
           "Medication"