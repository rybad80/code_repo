--© 2018-2023 Epic Systems Corporation. Confidential.
USE Caboodle_Aug;

WITH eavd AS (SELECT * FROM EncounterAttributeValueDim WHERE IsCurrent = 1)
SELECT MAX( encfact.EncounterEpicCsn ) "Encounter CSN",
       MAX( encdate.DisplayString ) "Encounter Date",
       MAX( patdim.Name ) "Patient Name",
       MAX( diagdim.Name ) "Primary Diagnosis",
	   MAX( CASE WHEN attdim.SmartDataElementEpicId = 'EPIC#OPH451' THEN eavd.Value ELSE NULL END ) "Dilated Eyes",
	   MAX( CASE WHEN attdim.SmartDataElementEpicId = 'EPIC#OPH452' THEN eavd.Value ELSE NULL END ) "Dilation Time",
	   MAX( CASE WHEN attdim.SmartDataElementEpicId = 'EPIC#OPH453' THEN eavd.Value ELSE NULL END ) "Dilation Medication"
  FROM eavd
	INNER JOIN AttributeDim attdim
	  ON eavd.AttributeKey = attdim.AttributeKey
	  AND attdim.SmartDataElementEpicId IN ( 'EPIC#OPH451', 'EPIC#OPH452', 'EPIC#OPH453' )
    RIGHT OUTER JOIN EncounterFact encfact
	  ON encfact.EncounterKey = eavd.EncounterKey
    INNER JOIN PatientDim patdim
      ON encfact.PatientDurableKey = patdim.DurableKey
		AND patdim.IsCurrent = 1
    INNER JOIN DiagnosisDim diagdim
      ON encfact.PrimaryDiagnosisKey = diagdim.DiagnosisKey
    INNER JOIN DepartmentDim depdim
      ON encfact.DepartmentKey = depdim.DepartmentKey
    INNER JOIN DateDim encdate
      ON encfact.DateKey = encdate.DateKey
  WHERE depdim.DepartmentEpicId = '10501103'
    AND encdate.DateValue >= '1/1/2008'
    AND encdate.DateValue < '1/1/2018'
  GROUP BY encfact.EncounterKey
  ORDER BY "Encounter CSN"