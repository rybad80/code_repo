/* © 2018-2023 Epic Systems Corporation. Confidential.
   Fill in the Current Patient MRN and Patient Name fields on the (Handout) 
   Registration Data on Patient Encounters. Update the query from the previous 
   exercise to replace the patient lookup column with these fields. */

USE Caboodle_Aug

SELECT PatientDim.Name,
       PatientDim.PrimaryMrn
  FROM BillingAccountFact
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN DateDim
  	  ON BillingAccountFact.AccountCreateDateKey = DateDim.DateKey
    INNER JOIN PatientDim
      ON BillingAccountFact.PatientDurableKey = PatientDim.DurableKey AND PatientDim.IsCurrent = 1
  WHERE DepartmentDim.ServiceAreaEpicId = '10'
    AND DateDim.DateValue >= DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) )
      -- the filter against CURRENT_TIMESTAMP is only necessary in the training environment that has future-dated data
    AND DateDim.DateValue <= CURRENT_TIMESTAMP