/* © 2018-2023 Epic Systems Corporation. Confidential.
   A requester asks you to write a report about the outpatient discharges that resulted
   in an inpatient reporting base class. The requester defines outpatient discharge
   events as the moment the patient last had a reporting base class of outpatient. Only
   consider the current, non-canceled interpretations of events. The report should count 
   the total number of admissions in each unit in the past three years. */

USE Clarity_Aug  

SELECT MAX( CLARITY_DEP.DEPARTMENT_NAME ) Department,
       COUNT( * ) NumOpDischToInp
  FROM CLARITY_ADT
    INNER JOIN CLARITY_DEP
	  ON CLARITY_ADT.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
  WHERE CLARITY_ADT.OUT_EVENT_TYPE_C = 2
    AND CLARITY_ADT.FROM_BASE_CLASS_C = 2
	AND CLARITY_ADT.TO_BASE_CLASS_C = 1
	AND CLARITY_ADT.EVENT_SUBTYPE_C <> 2
	AND CLARITY_ADT.EVENT_TYPE_C IN ( 4, 5, 8 )
	AND CLARITY_ADT.EFFECTIVE_TIME >= DATEADD( YEAR, -3, CAST( GETDATE( ) AS DATE ) )
  GROUP BY CLARITY_ADT.DEPARTMENT_ID
  ORDER BY COUNT ( * ) DESC