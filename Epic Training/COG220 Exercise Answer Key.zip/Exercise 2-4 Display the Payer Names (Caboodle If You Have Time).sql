/* © 2018-2023 Epic Systems Corporation. Confidential.
   Fill in the Primary Payer Name and Secondary Payer Name fields on the (Handout) Registration Data on Patient Encounters. 
   Update the query from the previous exercise to display the names of the primary and secondary payers.
   If you have time, additionally filter your query to only include HARs whose encounters have an encounter type of Office Visit.
   If you have even more time, rewrite this query using Clarity tables and columns. The training system uses PB SBO HARs to 
   track registration data on office visits. */

USE Caboodle_Aug

SELECT PatientDim.Name,
       PatientDim.PrimaryMrn,
       GuarantorDim.Name,
	   FirstCoverage.PayorName PrimaryPayer,
	   SecondCoverage.PayorName SecondaryPayer
  FROM BillingAccountFact
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN DateDim
  	  ON BillingAccountFact.AccountCreateDateKey = DateDim.DateKey
    INNER JOIN PatientDim
      ON BillingAccountFact.PatientDurableKey = PatientDim.DurableKey AND PatientDim.IsCurrent = 1
    INNER JOIN GuarantorDim
      ON BillingAccountFact.GuarantorDurableKey = GuarantorDim.DurableKey AND GuarantorDim.IsCurrent = 1
    INNER JOIN CoverageDim FirstCoverage
      ON BillingAccountFact.PrimaryCoverageKey = FirstCoverage.CoverageKey
    INNER JOIN CoverageDim SecondCoverage
      ON BillingAccountFact.SecondCoverageKey = SecondCoverage.CoverageKey
    INNER JOIN BillingAccountEncounterMappingFact
      ON BillingAccountFact.BillingAccountKey = BillingAccountEncounterMappingFact.BillingAccountKey
    INNER JOIN EncounterFact
      ON BillingAccountEncounterMappingFact.EncounterKey = EncounterFact.EncounterKey
  WHERE DepartmentDim.ServiceAreaEpicId = '10'
    AND DateDim.DateValue >= DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) )
      -- the filter against CURRENT_TIMESTAMP is only necessary in the training environment that has future-dated data
    AND DateDim.DateValue <= CURRENT_TIMESTAMP
    AND GuarantorDim.AccountType = 'Personal/Family'
    AND EncounterFact.Type = 'Office Visit'