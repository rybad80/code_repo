/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that returns all closed appointments. For each appointment, display the primary provider, 
   the department, and a column indicating whether the appointment was a joint appointment. Hint: I EPT 
   18120 indicates whether an appointment is closed.
   
   If you have time, return a count of appointments for each combination of primary provider and department.
   Include a count of how many of those appointments were joint appointments. */

USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName Department,
       ProviderDim.Name Provider,
	   CASE WHEN VisitFact.SecondVisitProviderDurableKey > 0 OR ( VisitFact.PrimaryResourceKey > 0 AND VisitFact.PrimaryVisitProviderDurableKey > 0 ) THEN 'Y' ELSE 'N' END JointApptYn
  FROM VisitFact
    INNER JOIN ProviderDim
      ON VisitFact.PrimaryVisitProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
    INNER JOIN DepartmentDim
      ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
  WHERE VisitFact.Closed = 1

/* If you have time
SELECT MAX( DepartmentDim.DepartmentName ) Department,
       MAX( ProviderDim.Name ) Provider,
	     COUNT( * ) NumOfAppts,
	     SUM( CASE WHEN VisitFact.SecondVisitProviderDurableKey > 0 OR ( VisitFact.PrimaryResourceKey > 0 AND VisitFact.PrimaryVisitProviderDurableKey > 0 ) THEN 1 ELSE 0 END ) NumJointAppts
  FROM VisitFact
    INNER JOIN ProviderDim
      ON VisitFact.PrimaryVisitProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
    INNER JOIN DepartmentDim
      ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
  WHERE VisitFact.Closed = 1
  GROUP BY VisitFact.DepartmentKey,
           VisitFact.PrimaryVisitProviderDurableKey
  ORDER BY NumOfAppts DESC,
           NumJointAppts DESC,
		       Department,
           Provider */