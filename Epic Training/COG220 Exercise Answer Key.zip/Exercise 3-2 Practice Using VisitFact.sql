/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report to return all visits with a visit type of office visit, an appointment status of scheduled,
   and an appointment date in the future. Display the department, provider, and appointment length in
   minutes for each visit. */

USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName "Department",
       ProviderDim.Name "Provider",
       VisitFact.AppointmentLengthInMinutes "Appt Length (Mins)"
  FROM VisitFact
    INNER JOIN ProviderDim
      ON VisitFact.PrimaryVisitProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
    INNER JOIN DepartmentDim
      ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN DateDim
      ON VisitFact.AppointmentDateKey = DateDim.DateKey
  WHERE VisitFact.AppointmentStatus = 'Scheduled'
    AND VisitFact.VisitType = 'Office Visit'
    AND DateDim.DateValue > CURRENT_TIMESTAMP