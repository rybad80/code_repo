/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization is interested in the actions users are taking to verify coverage members. 
   Write a report that finds the statuses that coverage member verification records move through 
   as they reach a verified status. Display changes in status that occur before or on the most 
   recent day that each qualifying verification record was verified. Sort the results by the 
   verification record ID and then by the chronological order of the status changes. Display the 
   verification record ID, name, what the status was, when each change in status occurred, and 
   the last time the verification record was verified.*/

USE Clarity_Aug

SELECT VERIF_STATUS_HX.RECORD_ID VerifRecordId,
       VERIFICATION.RECORD_NAME VerifRecordName,
	   ZC_REG_STATUS.NAME VerifStatus,
	   VERIF_STATUS_HX.STAT_CHNG_HX_DTTM StatusChangeInst,
	   VERIFICATION.LAST_VERIF_DATETIME LastVerifInst
  FROM VERIF_STATUS_HX
    INNER JOIN VERIFICATION
	  ON VERIF_STATUS_HX.RECORD_ID = VERIFICATION.RECORD_ID
	INNER JOIN ZC_REG_STATUS
	  ON VERIF_STATUS_HX.VERIF_STATUS_HX_C = ZC_REG_STATUS.REG_STATUS_C
        -- 6 means Coverage Member Verification
  WHERE VERIFICATION.VERIFICATION_TYPE_C = 6
    AND CAST( VERIF_STATUS_HX.STAT_CHNG_HX_DTTM AS DATE ) <= CAST( VERIFICATION.LAST_VERIF_DATETIME AS DATE )
  ORDER BY VERIF_STATUS_HX.RECORD_ID,
           VERIF_STATUS_HX.STAT_CHNG_HX_DTTM