/* © 2018-2023 Epic Systems Corporation. Confidential.
   You have received a request to write a report about how much of provider schedules is being 
   booked in the past year. The requester does not need you to explicitly handle late-cancel 
   appointments. Group the results by department. Only include slots that begin before 12:00 PM 
   and end no later than 12:00 PM. Display average schedule utilization percent a schedule's 
   regular available time that is being booked. */

USE Clarity_Aug

SELECT MAX( V_AVAILABILITY.DEPARTMENT_NAME ) Department,
       SUM( V_AVAILABILITY.NUM_APTS_SCHEDULED * V_AVAILABILITY.SLOT_LENGTH ) UsedTime,
	   SUM( V_AVAILABILITY.ORG_REG_OPENINGS * V_AVAILABILITY.SLOT_LENGTH ) AvailableRegTime,
	   SUM( V_AVAILABILITY.NUM_APTS_SCHEDULED * V_AVAILABILITY.SLOT_LENGTH ) * 100.0 / SUM( V_AVAILABILITY.ORG_REG_OPENINGS * V_AVAILABILITY.SLOT_LENGTH ) SchedBookedPct
  FROM V_AVAILABILITY
  WHERE V_AVAILABILITY.APPT_NUMBER = 0
    AND V_AVAILABILITY.SLOT_DATE >= DATEADD ( YEAR, -1, CURRENT_TIMESTAMP )
	AND V_AVAILABILITY.ORG_REG_OPENINGS > 0
	AND DATEADD( MINUTE, V_AVAILABILITY.SLOT_LENGTH, CAST( V_AVAILABILITY.SLOT_BEGIN_TIME AS TIME ) ) <= '12:00:00'
  GROUP BY V_AVAILABILITY.DEPARTMENT_ID
  ORDER BY SchedBookedPct DESC,
           Department