/* © 2018-2023 Epic Systems Corporation. Confidential.
   A report requester wants to see the activity from the past year of the users who work on preadmissions. 
   For every time a user has changed the admission status of a preadmission, display the user's name, when 
   the change happened, the resulting admission status.
   
   If you have time, for each user who has changed the admission status of a preadmission, display the 
   user's name and the number of times they set each admission status on preadmissions. */

USE Clarity_Aug

SELECT CLARITY_EMP.NAME StatusChangeUser,
       PAT_ENC_STAT_HX.UPDATE_TIME UpdateTime,
       ZC_CONF_STAT.NAME AdmissionStatus
  FROM PAT_ENC_STAT_HX
    INNER JOIN CLARITY_EMP
	  ON PAT_ENC_STAT_HX.UPDATE_USER_ID = CLARITY_EMP.USER_ID
	INNER JOIN ZC_CONF_STAT
	  ON PAT_ENC_STAT_HX.UPDATED_CONF_STAT_C = ZC_CONF_STAT.ADMIT_CONF_STAT_C
  WHERE PAT_ENC_STAT_HX.UPDATE_TIME >= CAST( DATEADD( YEAR, -1, CURRENT_TIMESTAMP ) AS DATE )
    -- 1 is preadmission
    AND PAT_ENC_STAT_HX.UPDATED_ENC_STAT_C = 1

/* If you have time
SELECT MAX( CLARITY_EMP.NAME ) StatusChangeUser,
       MAX( ZC_CONF_STAT.NAME ) AdmissionStatus,
       COUNT( * ) NumPreadmissions
  FROM PAT_ENC_STAT_HX
    INNER JOIN CLARITY_EMP
	  ON PAT_ENC_STAT_HX.UPDATE_USER_ID = CLARITY_EMP.USER_ID
	INNER JOIN ZC_CONF_STAT
	  ON PAT_ENC_STAT_HX.UPDATED_CONF_STAT_C = ZC_CONF_STAT.ADMIT_CONF_STAT_C
  WHERE PAT_ENC_STAT_HX.UPDATE_TIME >= CAST( DATEADD( YEAR, -1, CURRENT_TIMESTAMP ) AS DATE )
    -- 1 is preadmission
    AND PAT_ENC_STAT_HX.UPDATED_ENC_STAT_C = 1
  GROUP BY CLARITY_EMP.USER_ID,
           PAT_ENC_STAT_HX.UPDATED_CONF_STAT_C
  ORDER BY MAX( CLARITY_EMP.NAME ) */