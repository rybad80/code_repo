/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that compares authorization approval methods. Return the:
     - number of approved authorizations
     - percent of approved authorizations that were authorized through ASA
	 - percent of approved authorizations that were authorized through RTA
	 - percent of approved authorizations that were authorized manually (not ASA and not RTA)
   Display the percents with two decimal places. Group the authorizations by the 
   destination department. Only include authorizations created in the past year. */

USE Caboodle_Aug

SELECT MAX( DepartmentDim.DepartmentName ) "Department",
	   /* number of authorizations */ "# Auths",
	   CAST( /* aggregate number of ASA-authorized rows */ * 1.0 / /* number of authorizations */ * 100 AS NUMERIC( 18,2 ) ) "% ASA Approved",
	   CAST( /* aggregate number of RTA-authorized rows */ ) * 1.0 / /* number of authorizations */ * 100 AS NUMERIC( 18,2 ) ) "% RTA Approved",
	   CAST( SUM( CASE /* when the row wasn't ASA-authorized and wasn't RTA-authorized */ THEN 1 
	              ELSE 0 END ) * 1.0 / /* number of authorizations */ ) * 100 AS NUMERIC( 18,2 ) ) "% Manually Approved"
  FROM AuthorizationFact
    INNER JOIN DateDim
	  ON AuthorizationFact.CreationDateKey = DateDim.DateKey
	INNER JOIN DepartmentDim
	  ON AuthorizationFact.ReferredToDepartmentKey = DepartmentDim.DepartmentKey
  WHERE DateDim.DateValue >= DATEADD( YEAR, -1, GETDATE( ) )
	AND AuthorizationFact.IsApproved = 1
  GROUP BY DepartmentDim.DepartmentKey
  ORDER BY "Department"