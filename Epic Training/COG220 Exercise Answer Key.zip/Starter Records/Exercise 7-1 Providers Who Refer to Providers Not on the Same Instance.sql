/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization would like to reduce the number of referrals that originate from 
   internal providers and are sent to providers not on your instance of Epic. Write a 
   report to find those referrals. For each referral, display the name of the referring
   provider, the primary procedure, the referral's status, and whether the referral is 
   considered leaked.
   If you have time, group those referrals by referring provider and primary procedure.
   Display provider's name, the procedure name, the number of referrals, the number of 
   those referrals that are in a status of Authorized, and the number of those referrals
   that are considered leaked. */

USE Caboodle_Aug

SELECT ProviderDim.Name Provider,
       ProcedureDim.Name ProcedureName,
	   ReferralFact./* use the FullAccess simplification of the IsLeaked column */ LeakedYn,
	   ReferralFact.Status Status
  FROM ReferralFact
    INNER JOIN ProviderDim
	  ON ReferralFact./* column that identifies the referring provider */ = ProviderDim./* appropriate column */ AND ProviderDim./* condition to return only current data */
	INNER JOIN ProcedureDim
	  ON ReferralFact.PrimaryProcedureDurableKey = ProcedureDim.DurableKey
  WHERE	ReferralFact./* filter to referrals leaving our instance of Epic */