/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization would like to reduce the length of time patients must wait between 
   checking in and being roomed for office visits. For each visit with a visit type of 
   office visit, display the department, the primary visit provider, and the wait time 
   between check-in and rooming in minutes.
   If you have time, display the average wait time and number of visits for each primary 
   provider in each department for office visits. */

USE Clarity_Aug

SELECT V_SCHED_APPT.DEPARTMENT_NAME Department,
       V_SCHED_APPT.PROV_NAME_WID Provider,
       /* duration of the wait */ MinutesToRoom
  FROM V_SCHED_APPT
  WHERE V_SCHED_APPT./* filter visit type column to office visits */