/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that displays how long each encounter spends in the Med Surg unit in minutes. 
   For each encounter, also display its CSN and the name of the patient.
   The Med Surg department has an ID of 10101102. */

 USE Clarity_Aug

SELECT V_PAT_ADT_LOCATION_HX.PAT_ENC_CSN "CSN",
       MAX( /* patient name */ ) "Patient Name",
	   SUM( DATEDIFF( MINUTE, /* bed entry timestamp */, /* bed exit timestamp */) ) "Total time in EMH Med Surg"
  FROM V_PAT_ADT_LOCATION_HX
    INNER JOIN PAT_ENC 
	  ON V_PAT_ADT_LOCATION_HX.PAT_ENC_CSN = PAT_ENC.PAT_ENC_CSN_ID
	INNER JOIN PATIENT
	  ON PAT_ENC.PAT_ID = PATIENT.PAT_ID
  WHERE V_PAT_ADT_LOCATION_HX./* filter to correct department */
      --Discard training data from future dates
    AND V_PAT_ADT_LOCATION_HX.IN_DTTM < CURRENT_TIMESTAMP
	AND V_PAT_ADT_LOCATION_HX.PAT_OUT_DTTM IS NOT NULL
  GROUP BY V_PAT_ADT_LOCATION_HX.PAT_ENC_CSN