/* © 2018-2023 Epic Systems Corporation. Confidential.
   Find the average difference in minutes between the event times of 
   canceled discharge events and their update discharge events. */

 USE Clarity_Aug

SELECT MAX( /* user's name */ ) UpdateUser,
       AVG( DATEDIFF( MINUTE, /* canceled event's time */, /* updated event's time */ ) ) AvgMinsBtwnCancAndUpd
  FROM CLARITY_ADT UpdDisch
    INNER JOIN CLARITY_ADT CancDisch
      ON UpdDisch./* column to ID the replaced event */ = CancDisch./* event ID */
    INNER JOIN CLARITY_EMP
      ON UpdDisch.USER_ID = CLARITY_EMP.USER_ID
  WHERE UpdDisch./* filter to discharge events */
    AND CancDisch./* filter to discharge events */
    AND CancDisch./* only include events that have been canceled */
  GROUP BY UpdDisch.USER_ID