/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization would like to reduce the length of time patients must wait between 
   checking in and being roomed for office visits. For each visit with a visit type of 
   office visit, display the department, the primary visit provider, and the wait time 
   between check-in and rooming in minutes.
   If you have time, display the average wait time and number of visits for each primary 
   provider in each department for office visits. */


USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName Department,
       ProviderDim.Name Provider,
       /* column representing duration of the wait */ MinutesToRoom
  FROM VisitFact 
    INNER JOIN DepartmentDim
	    ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
	  INNER JOIN ProviderDim
	    ON VisitFact./* column that IDs the visit provider */ = ProviderDim./* appropriate joining column */ AND ProviderDim./* condition to return only current data */
  WHERE VisitFact./* filter on visit type */