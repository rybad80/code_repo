/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization is interested in the actions users are taking to verify coverage members. 
   Write a report that finds the statuses that coverage member verification records move through 
   as they reach a verified status. Display changes in status that occur before or on the most 
   recent day that each qualifying verification record was verified. Sort the results by the 
   verification record ID and then by the chronological order of the status changes. Display the 
   verification record ID, name, what the status was, when each change in status occurred, and 
   the last time the verification record was verified.*/

USE Clarity_Aug

SELECT VERIF_STATUS_HX.RECORD_ID VerifRecordId,
       /* fill in column */ VerifRecordName,
	   /* ZC table's Name column */ VerifStatus,
	   VERIF_STATUS_HX.STAT_CHNG_HX_DTTM StatusChangeInst,
	   /* fill in column */ LastVerifInst
  FROM VERIF_STATUS_HX
    INNER JOIN /* the table that provide details about the VRX record */
	  ON VERIF_STATUS_HX.RECORD_ID = /* fill in column */
	INNER JOIN /* find the ZC table from VERIF_STATUS_HX's Foreign Key Information */
	  ON VERIF_STATUS_HX.VERIF_STATUS_HX_C = /* fill in column */
  WHERE VERIFICATION.VERIFICATION_TYPE_C = /* the value that means Coverage Member Verification */
    AND CAST( /* column representing a status change */ AS DATE ) <= CAST( /* column representing the last time verified */ AS DATE )
  ORDER BY VERIF_STATUS_HX.RECORD_ID,
           VERIF_STATUS_HX.STAT_CHNG_HX_DTTM