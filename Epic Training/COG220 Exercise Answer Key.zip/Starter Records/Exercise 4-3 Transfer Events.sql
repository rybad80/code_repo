/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that tracks the number of transfers where patients were transferred 
   from the Emergency Department (ID: 10101100) to the Med Surg department (ID: 10101102). */

 USE Clarity_Aug

SELECT COUNT(*) NumTxsFromEDToMedSurg
  FROM CLARITY_ADT EdXferOut
    INNER JOIN CLARITY_ADT MsXferIn
	  ON EdXferOut./* column that IDs the paired transfer in */ = MsXferIn./* the transfer in event's ID */
  WHERE /* make sure the transfer out occurs in the ED */
    AND /* make sure the transfer in occurs in Med Surg */
    AND /* make sure the transfer out isn't canceled */
	AND /* make sure the transfer in isn't canceled */
	AND /* make sure the transfer out is actually a transfer out */
	AND /* make sure the transfer in is actually a transfer in */