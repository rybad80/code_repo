/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization wants to know how many patients are canceling appointments without rescheduling them. 
   Write a report to find appointments that were canceled by patients but have no non-canceled reschedule. For 
   these canceled appointments, display the department name, provider name, appointment date, and the cancel 
   reason. Additionally, display whether it was a same day cancel. */

USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName "Department",
       ProviderDim.Name "Provider",
       DateDim.DisplayString "Appointment Date",
       VisitFact.ReasonAppointmentCanceled "Cancel Reason",
       /* hint: use a FullAccess _YesNo version of the 1/0 column */ "Same Day Cancel?"
  FROM VisitFact
    INNER JOIN DepartmentDim
      ON /* condition to return the department */
    INNER JOIN ProviderDim
      ON /* condition that returns the most current data about the primary provider */
    INNER JOIN DateDim
      ON /* condition to return the appointment's date */
  WHERE /* condition to only return rows that did not load an identifier for a different appointment */
    AND /* condition to only return rows that are canceled */
    AND /* condition to return only cases where the patient was the cause of the cancelation */