/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that displays how long each encounter spends in the Med Surg unit in minutes. 
   For each encounter, also display its CSN and the name of the patient.
   The Med Surg department has an ID of 10101102. */

USE Caboodle_Aug

SELECT MAX( /* CSN column */ ) CSN,
       MAX( /* patient name */ ) Patient,
       SUM( PatientLocationEventFact.EventLengthInMinutes ) MinsInMedSurg
  FROM PatientLocationEventFact
    INNER JOIN DepartmentDim
	  ON PatientLocationEventFact.DepartmentKey = DepartmentDim.DepartmentKey
	INNER JOIN EncounterFact
	  ON PatientLocationEventFact.EncounterKey = EncounterFact.EncounterKey
	INNER JOIN PatientDim
	  ON PatientLocationEventFact.PatientDurableKey = PatientDim.DurableKey AND PatientDim.IsCurrent = 1
	  -- to get rid of future training data
	INNER JOIN DateDim
	  ON PatientLocationEventFact.StartDateKey = DateDim.DateKey
  WHERE DepartmentDim./* only include rows about Med Surg */
      -- get rid of future training data
    AND DateDim.DateValue < CURRENT_TIMESTAMP
  GROUP BY PatientLocationEventFact.EncounterKey
  HAVING SUM( EventLengthInMinutes ) IS NOT NULL