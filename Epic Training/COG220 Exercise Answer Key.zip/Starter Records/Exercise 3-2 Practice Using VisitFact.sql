/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report to return all visits with a visit type of office visit, an appointment status of scheduled,
   and an appointment date in the future. Display the department, provider, and appointment length in
   minutes for each visit. */

USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName "Department",
       ProviderDim.Name "Provider",
       VisitFact.AppointmentLengthInMinutes "Appt Length (Mins)"
  FROM VisitFact
    INNER JOIN ProviderDim
      ON /* condition that returns the most current data about the primary provider */
    INNER JOIN DepartmentDim
      ON /* condition to return the department */
    INNER JOIN DateDim
      ON /* condition to return the appointment's date */
  WHERE /* condition to only return scheduled rows */
    AND /* condition to only return office visits */
    AND DateDim.DateValue > CURRENT_TIMESTAMP
