/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that shows all actions patients take when completing their Welcome Check In workflows. 
   Only show actions where the workflow attempt was successful. For each action, display the 
   action type, subtype, outcome, action order in the workflow attempt, and instant. */


USE Caboodle_Aug

SELECT /* table that focuses on actions */./* column about action types */ "Type",
       /* table that focuses on actions */./* column about action subtypes */ "Subtype",
       /* table that focuses on actions */./* column about action outcomes */ "Outcome",
       /* table that focuses on actions */./* column about action order */ "Order in Attempt",
       /* table that focuses on actions */./* column about action instant*/ "Instant"
  FROM PatientApplicationActionFact
    INNER JOIN PatientWorkflowAttemptFact
      ON PatientApplicationActionFact.PatientWorkflowAttemptKey = PatientWorkflowAttemptFact.PatientWorkflowAttemptKey
  WHERE PatientWorkflowAttemptFact./* filter to find successful attempts */
    AND PatientWorkflowAttemptFact./* filter to specifically find Welcome Check In workflows */