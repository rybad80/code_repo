/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that compares authorization approval rates. Calculate the number of
   authorizations and the percent of approved authorizations broken down by type of
   authorization (referral-level, coverage-level, SLA, and auth/cert) and specialty.
   Only include authorizations created in the past year. */

USE Caboodle_Aug

SELECT AuthorizationFact.Specialty "Specialty",
       AuthorizationFact.TypeOfAuthorization "Type of Auth",
	   /* aggregate number of authorizations */ "# Auths",
	   SUM( AuthorizationFact./* 1/0 column indicating whether approved */ ) * 1.0 / /* aggregate number of authorizations */ * 100 "% Approved"
  FROM AuthorizationFact
    INNER JOIN DateDim
	  ON AuthorizationFact./* column indicating when authorization was created */ = DateDim.DateKey
  WHERE DateDim.DateValue >= DATEADD( YEAR, -1, GETDATE( ) )
  GROUP BY AuthorizationFact.Specialty,
           AuthorizationFact.TypeOfAuthorization
  ORDER BY "Specialty",
           "Type of Auth"