/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that tracks the number of transfers where patients were transferred 
   from the Emergency Department (ID: 10101100) to the Med Surg department (ID: 10101102). */


USE Clarity_Aug

SELECT COUNT(*) NumTxsFromEDToMedSurg
  FROM CLARITY_ADT EdXferOut
    INNER JOIN CLARITY_ADT MsXferIn
	  ON EdXferOut.XFER_IN_EVENT_ID = MsXferIn.EVENT_ID
  WHERE EdXferOut.DEPARTMENT_ID = 10101100
    AND MsXferIn.DEPARTMENT_ID = 10101102
    AND EdXferOut.EVENT_SUBTYPE_C <> 2
	AND MsXferIn.EVENT_SUBTYPE_C <> 2
	AND EdXferOut.EVENT_TYPE_C = 4
	AND MsXferIn.EVENT_TYPE_C = 3