/* © 2018-2023 Epic Systems Corporation. Confidential.
   You have received a request to write a report about how much of provider schedules is being booked 
   in the past year. The requester does not need you to explicitly handle late-cancel appointments. 
   Group the results by department and provider. Display the average percent of a schedule's regular 
   available time that is being booked. */

USE Clarity_Aug

SELECT MAX( CLARITY_DEP.DEPARTMENT_NAME ) Department,
       MAX( CLARITY_SER.PROV_NAME ) Provider,
	   AVG( F_SCHED_APPT_STATS.BOOKED_HRS * 100.0 / F_SCHED_APPT_STATS.REG_AVAILABLE_HRS ) SchedBookedPct
  FROM F_SCHED_APPT_STATS
    INNER JOIN CLARITY_DEP
	  ON F_SCHED_APPT_STATS.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
	INNER JOIN CLARITY_SER
	  ON F_SCHED_APPT_STATS.PROV_ID = CLARITY_SER.PROV_ID
  WHERE F_SCHED_APPT_STATS.STATISTICS_DATE >= DATEADD( YEAR, -1, CAST( GETDATE( ) AS DATE ) )
    AND F_SCHED_APPT_STATS.REG_AVAILABLE_HRS > 0
  GROUP BY F_SCHED_APPT_STATS.DEPARTMENT_ID,
           F_SCHED_APPT_STATS.PROV_ID
  ORDER BY SchedBookedPct DESC