/* © 2018-2023 Epic Systems Corporation. Confidential.
   A requester asks you to write a report about the inpatient admission events that have 
   occurred in the past three years, by department. The inpatient admission events are defined 
   as the event that represents the first time a patient was admitted with an inpatient base 
   class in an inpatient-type unit. Only consider the current, non-canceled interpretations of 
   events. The report should count the total number of admissions in each unit in the past 
   three years. */

USE Clarity_Aug

SELECT MAX( CLARITY_DEP.DEPARTMENT_NAME ) Department,
       COUNT( * ) NumInpAdms
  FROM CLARITY_ADT
    INNER JOIN CLARITY_DEP
	  ON CLARITY_ADT.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
  WHERE	CLARITY_ADT.FIRST_IP_IN_IP_YN = 'Y'
  	-- only these event types could cause a person to take on an inpatient reporting base class in an inpatient bed
  	AND CLARITY_ADT.EVENT_TYPE_C IN ( 1, 3, 5, 9 )
	AND CLARITY_ADT.EVENT_SUBTYPE_C IN ( 1, 3 )
	AND CLARITY_ADT.EFFECTIVE_TIME >= DATEADD( YEAR, -3, CAST( CURRENT_TIMESTAMP AS DATE ) )
  GROUP BY CLARITY_DEP.DEPARTMENT_ID
  ORDER BY NumInpAdms DESC