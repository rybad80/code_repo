/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report to find admission events that occurred in the EMH Emergency department (ID = 10101100) that had 
   no intervening ADT events before a transfer event to the EMH Main OR department (ID = 10101110). Only include admissions
   that occurred in June of 2023. Display the room to which they were admitted, the name and MRN of the patient, the 
   effective time of the admission, and the effective time of the transfer. Your results should reproduce the information 
   that was valid for those admission events as of July 1, 2023. */

USE Clarity_Aug

SELECT CLARITY_ROM.ROOM_NAME Room,
       PATIENT.PAT_NAME Patient,
	   PATIENT.PAT_MRN_ID PatMrnId,
	   admit.EFFECTIVE_TIME TimeOfAdmission,
	   txIN.EFFECTIVE_TIME TimeOfTransfer,
     	   admit.EVENT_SUBTYPE_C,
	   txin.EVENT_SUBTYPE_C,
	   admit.event_time,
	   txin.event_time
  FROM CLARITY_ADT admit
    -- CLARITY_ROM has weekly extracts
    LEFT OUTER JOIN CLARITY_ROM
	  ON admit.ROOM_CSN_ID = CLARITY_ROM.ROOM_CSN_ID
	INNER JOIN PATIENT
	  ON admit.PAT_ID = PATIENT.PAT_ID
	-- find the transfer in event following the transfer out event following the admission in the encounter
	INNER JOIN CLARITY_ADT txIN
	  ON admit.SEQ_NUM_IN_ENC + 2 = txin.SEQ_NUM_IN_ENC 
	    AND admit.PAT_ENC_CSN_ID = txin.PAT_ENC_CSN_ID
  WHERE admit.DEPARTMENT_ID = 10101100
    AND admit.EVENT_TYPE_C = 1
    AND admit.EFFECTIVE_TIME >= '6/1/2023'
    AND admit.EFFECTIVE_TIME < '7/1/2023'
    		 -- original or updated event
    AND (	( admit.EVENT_SUBTYPE_C <> 2
              -- became valid before the test date
              -- original and updated events are valid through now, so we don't need to explicitly test an end boundary
              AND admit.EVENT_TIME <= '7/1/2023' )
  			    -- canceled event
    		    OR ( admit.EVENT_SUBTYPE_C = 2
  			       -- canceled after the test date (became invalid after the test date)
  			       AND admit.DELETE_TIME > '7/1/2023'
  				   -- became valid before the test date)
  				   AND admit.EVENT_TIME <= '7/1/2023' ) )
    -- the destination should be EMH ICU
    AND txin.DEPARTMENT_ID = 10101110
    AND txin.EVENT_TYPE_C = 3