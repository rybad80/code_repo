/* © 2018-2023 Epic Systems Corporation. Confidential.
   Create a report on joint appointments in Clarity. The report should be limited to only closed 
   joint appointments and should display all providers and departments associated with the appointment. 
   Include a flag that indicates if a row represents a provider acting as the primary provider for an appointment.
   Hint: I EPT 18120 indicates whether an appointment is closed. */


USE Clarity_Aug

SELECT CLARITY_SER.PROV_NAME Provider,
       CLARITY_DEP.DEPARTMENT_NAME Department,
	   CASE WHEN appt1.LINE = 1 THEN 'Primary'
	        ELSE 'Not Primary' END PrimaryProvYN
  FROM PAT_ENC_APPT appt1
    -- Only include encounters with more than one provider/department
    INNER JOIN PAT_ENC_APPT appt2
      ON appt1.PAT_ENC_CSN_ID = appt2.PAT_ENC_CSN_ID
  	  AND appt2.LINE = 2
    INNER JOIN PAT_ENC
      ON appt1.PAT_ENC_CSN_ID = PAT_ENC.PAT_ENC_CSN_ID
    INNER JOIN CLARITY_SER
      ON appt1.PROV_ID = CLARITY_SER.PROV_ID
    INNER JOIN CLARITY_DEP
      ON appt1.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
  WHERE PAT_ENC.ENC_CLOSED_YN = 'Y'