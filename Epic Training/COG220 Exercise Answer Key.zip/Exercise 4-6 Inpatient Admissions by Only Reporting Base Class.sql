/* © 2018-2023 Epic Systems Corporation. Confidential.
   A requester asks you to write a report about the inpatient admission events that have occurred
   in the past three years. The requester defines inpatient admission events as the moment the 
   patient first had a reporting base class of inpatient. It does not matter whether the patient 
   occupied an inpatient bed. For each inpatient admission event, display the department in which 
   the event occurred, the patient name, the encounter CSN, the event type, and when the event 
   happened.
   
   If you have time, write a query that returns the total number of inpatient admissions in each 
   department in the past three years. */


 USE Clarity_Aug

SELECT CLARITY_DEP.DEPARTMENT_NAME Department,
       PATIENT.PAT_NAME Patient,
	   CLARITY_ADT.PAT_ENC_CSN_ID Csn,
	   ZC_EVENT_TYPE.NAME EventType,
	   CLARITY_ADT.EFFECTIVE_TIME EffectiveTime
  FROM CLARITY_ADT
    INNER JOIN CLARITY_DEP
	  ON CLARITY_ADT.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
	INNER JOIN PATIENT
	  ON CLARITY_ADT.PAT_ID = PATIENT.PAT_ID
	INNER JOIN ZC_EVENT_TYPE
	  ON CLARITY_ADT.EVENT_TYPE_C = ZC_EVENT_TYPE.EVENT_TYPE_C
        --Inpatient base class
  WHERE CLARITY_ADT.TO_BASE_CLASS_C = 1
        --Interpreted admission event
	AND CLARITY_ADT.IN_EVENT_TYPE_C = 1
    AND CLARITY_ADT.EVENT_SUBTYPE_C <> 2
    AND CLARITY_ADT.EFFECTIVE_TIME >= DATEADD( YEAR, -3, CAST ( CURRENT_TIMESTAMP AS DATE ) )

/* If you have time
SELECT MAX( CLARITY_DEP.DEPARTMENT_NAME ) Department,
       COUNT( * ) NumInpAdms
  FROM CLARITY_ADT
    INNER JOIN CLARITY_DEP
	  ON CLARITY_ADT.DEPARTMENT_ID = CLARITY_DEP.DEPARTMENT_ID
        --Inpatient base class
  WHERE CLARITY_ADT.TO_BASE_CLASS_C = 1
        --Interpreted admission event
	AND CLARITY_ADT.IN_EVENT_TYPE_C = 1
    AND CLARITY_ADT.EVENT_SUBTYPE_C <> 2
    AND CLARITY_ADT.EFFECTIVE_TIME >= DATEADD( YEAR, -3, CAST ( CURRENT_TIMESTAMP AS DATE ) )
  GROUP BY CLARITY_DEP.DEPARTMENT_ID
  ORDER BY NumInpAdms DESC */