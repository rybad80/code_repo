/* © 2018-2023 Epic Systems Corporation. Confidential.
   Fill in the Primary Payer Name and Secondary Payer Name fields on the (Handout) Registration Data on Patient Encounters. 
   Update the query from the previous exercise to display the names of the primary and secondary payers.
   If you have time, additionally filter your query to only include HARs whose encounters have an encounter type of Office Visit.
   If you have even more time, rewrite this query using Clarity tables and columns. The training system uses PB SBO HARs to 
   track registration data on office visits. */

USE Clarity_Aug

SELECT PATIENT.PAT_NAME PatientName,
	     PATIENT.PAT_MRN_ID PrimaryMrn,
	     ACCOUNT.ACCOUNT_NAME GuarantorName,
	     V_COVERAGE_PAYOR_PLAN.PAYOR_NAME PayerName,
       CASE WHEN HSP_ACCT_CVG_LIST.LINE = 1 THEN 'Primary'
	          WHEN HSP_ACCT_CVG_LIST.LINE = 2 THEN 'Secondary'
		  	    ELSE 'No Coverage' END FilingOrder
  FROM HSP_ACCOUNT
    INNER JOIN PATIENT
      ON HSP_ACCOUNT.PAT_ID = PATIENT.PAT_ID
    INNER JOIN ACCOUNT
      ON HSP_ACCOUNT.GUARANTOR_ID = ACCOUNT.ACCOUNT_ID
    LEFT OUTER JOIN HSP_ACCT_CVG_LIST
      ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_CVG_LIST.HSP_ACCOUNT_ID AND HSP_ACCT_CVG_LIST.LINE <= 2
    LEFT OUTER JOIN V_COVERAGE_PAYOR_PLAN
      ON HSP_ACCT_CVG_LIST.COVERAGE_ID = V_COVERAGE_PAYOR_PLAN.COVERAGE_ID
    INNER JOIN HSP_ACCT_PAT_CSN
      ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_PAT_CSN.HSP_ACCOUNT_ID
    INNER JOIN PAT_ENC
      ON HSP_ACCT_PAT_CSN.PAT_ENC_CSN_ID = PAT_ENC.PAT_ENC_CSN_ID
  WHERE HSP_ACCOUNT.SERV_AREA_ID = 10
    AND HSP_ACCOUNT.RECORD_CREATE_DATE >= DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) )
    AND HSP_ACCOUNT.RECORD_CREATE_DATE <= CURRENT_TIMESTAMP
    -- 1 is Personal/Family
    AND ACCOUNT.ACCOUNT_TYPE_C = 1
    -- 101 = Office Visit in I EPT 30
    AND PAT_ENC.ENC_TYPE_C = '101'
