/* © 2018-2023 Epic Systems Corporation. Confidential.
   Find the average difference in minutes between the event times of 
   canceled discharge events and their update discharge events. */

 USE Clarity_Aug

SELECT MAX( CLARITY_EMP.NAME ) UpdateUser,
       AVG( DATEDIFF( MINUTE, CancDisch.EVENT_TIME, UpdDisch.EVENT_TIME ) ) AvgMinsBtwnCancAndUpd
  FROM CLARITY_ADT UpdDisch
    INNER JOIN CLARITY_ADT CancDisch
      ON UpdDisch.CANC_EVENT_ID = CancDisch.EVENT_ID
    INNER JOIN CLARITY_EMP
      ON UpdDisch.USER_ID = CLARITY_EMP.USER_ID
  WHERE UpdDisch.EVENT_TYPE_C = 2
    AND CancDisch.EVENT_TYPE_C = 2
    AND CancDisch.EVENT_SUBTYPE_C = 2
  GROUP BY UpdDisch.USER_ID