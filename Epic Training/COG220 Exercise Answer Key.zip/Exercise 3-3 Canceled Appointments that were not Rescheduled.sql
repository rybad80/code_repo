/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization wants to know how many patients are canceling appointments without rescheduling them. 
   Write a report to find appointments that were canceled by patients but have no non-canceled reschedule. For 
   these canceled appointments, display the department name, provider name, appointment date, and the cancel 
   reason. Additionally, display whether it was a same day cancel. */

USE Caboodle_Aug

SELECT DepartmentDim.DepartmentName "Department",
       ProviderDim.Name "Provider",
       DateDim.DisplayString "Appointment Date",
       VisitFact.ReasonAppointmentCanceled "Cancel Reason",
       VisitFact.IsSameDayCancel_YesNo "Same Day Cancel?"
  FROM VisitFact
    INNER JOIN DepartmentDim
      ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN ProviderDim
      ON VisitFact.PrimaryVisitProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
    INNER JOIN DateDim
      ON VisitFact.AppointmentDateKey = DateDim.DateKey
  WHERE VisitFact.RescheduledVisitKey = -1
    AND VisitFact.AppointmentStatus = 'Canceled'
    AND VisitFact.CancellationInitiator = 'Patient'