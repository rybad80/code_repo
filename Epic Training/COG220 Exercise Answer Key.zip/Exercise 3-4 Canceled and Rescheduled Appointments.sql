/* © 2018-2023 Epic Systems Corporation. Confidential.
   You have received a request to write a report about canceled appointments that have been rescheduled. 
   Display the provider name, department name, appointment date and time for both the canceled and 
   rescheduled appointments, as well as the cancel reason. */
 

USE Caboodle_Aug

SELECT CancDep.DepartmentName CanceledDepartment,
       CancProv.Name CanceledProvider,
       CancDate.DisplayString CanceledDate,
       CanceledAppt.ReasonAppointmentCanceled CancelReason,
       ReschedDep.DepartmentName ReschedDepartment,
       ReschedProv.Name ReschedProvider,
       ReschedDate.DisplayString ReschedDate   
  FROM VisitFact CanceledAppt
    INNER JOIN VisitFact ReschedAppt
      ON CanceledAppt.RescheduledVisitKey = ReschedAppt.VisitKey
    INNER JOIN DepartmentDim CancDep
      ON CanceledAppt.DepartmentKey = CancDep.DepartmentKey
    INNER JOIN ProviderDim CancProv
      ON CanceledAppt.PrimaryVisitProviderDurableKey = CancProv.DurableKey AND CancProv.IsCurrent = 1
    INNER JOIN DateDim CancDate
      ON CanceledAppt.AppointmentDateKey = CancDate.DateKey
    INNER JOIN DepartmentDim ReschedDep
      ON ReschedAppt.DepartmentKey = ReschedDep.DepartmentKey
    INNER JOIN ProviderDim ReschedProv
      ON ReschedAppt.PrimaryVisitProviderDurableKey = ReschedProv.DurableKey AND ReschedProv.IsCurrent = 1
    INNER JOIN DateDim ReschedDate
      ON ReschedAppt.AppointmentDateKey = ReschedDate.DateKey
  WHERE CanceledAppt.RescheduledVisitKey > 0