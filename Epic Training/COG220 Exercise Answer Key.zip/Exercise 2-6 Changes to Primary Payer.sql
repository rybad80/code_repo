/* © 2018-2023 Epic Systems Corporation. Confidential.
   You would like to investigate filing order changes involving the Aetna payer. Your report will list 
   each time the primary payer on a hospital account was changed from Aetna (payer ID 100) to any other payer. 
   You will display the names of the old and new primary payer and also display the patient name and MRN 
   the filing order change was for.
   
   HINT: Filing order changes are captured in registration history events. The event type that corresponds
   to a hospital account coverage list change is event type category value 67. */

USE Clarity_Aug

SELECT V_OLD.PAYOR_NAME OldPayer,
	   V_NEW.PAYOR_NAME NewPayer,
	   PATIENT.PAT_NAME Patient,
	   PATIENT.PAT_MRN_ID PatMrnId
  FROM REG_HX
    INNER JOIN PATIENT
	  ON REG_HX.REG_HX_OPEN_PAT_ID = PATIENT.PAT_ID
    INNER JOIN REG_HX_OLD_FILE_ORD
	  ON REG_HX.REG_HX_EVENT_ID = REG_HX_OLD_FILE_ORD.REG_HX_EVENT_ID
	INNER JOIN REG_HX_NEW_FILE_ORD
	  ON REG_HX.REG_HX_EVENT_ID = REG_HX_NEW_FILE_ORD.REG_HX_EVENT_ID
	INNER JOIN V_COVERAGE_PAYOR_PLAN V_NEW
	  ON REG_HX_NEW_FILE_ORD.REG_HX_NEW_FO_ID = V_NEW.COVERAGE_ID
	INNER JOIN V_COVERAGE_PAYOR_PLAN V_OLD
	  ON REG_HX_OLD_FILE_ORD.REG_HX_OLD_FO_ID = V_OLD.COVERAGE_ID
        --100 is Aetna
  WHERE V_OLD.PAYOR_ID = 100
        --Hospital Account filing order changes
	AND REG_HX.REG_HX_EVENT_C = 67
	    --Primary coverage only
	AND REG_HX_NEW_FILE_ORD.LINE = 1
	    --Primary coverage only
	AND REG_HX_OLD_FILE_ORD.LINE = 1
	AND V_NEW.PAYOR_ID <> V_OLD.PAYOR_ID