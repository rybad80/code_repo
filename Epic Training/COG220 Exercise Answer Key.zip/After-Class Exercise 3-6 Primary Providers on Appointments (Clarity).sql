/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that returns all closed appointments. For each appointment, display the primary provider, 
   the department, and a column indicating whether the appointment was a joint appointment. Hint: I EPT 
   18120 indicates whether an appointment is closed.
   
   If you have time, return a count of appointments for each combination of primary provider and department.
   Include a count of how many of those appointments were joint appointments. */

USE Clarity_Aug

SELECT V_SCHED_APPT.DEPARTMENT_NAME Department,
       V_SCHED_APPT.PROV_NAME_WID Provider,
	   V_SCHED_APPT.JOINT_APPT_YN JointApptYn
  FROM V_SCHED_APPT
    INNER JOIN PAT_ENC
	    ON V_SCHED_APPT.PAT_ENC_CSN_ID = PAT_ENC.PAT_ENC_CSN_ID
  WHERE PAT_ENC.ENC_CLOSED_YN = 'Y'

/* If you had time
  SELECT MAX( V_SCHED_APPT.DEPARTMENT_NAME ) Department,
         V_SCHED_APPT.PROV_NAME_WID Provider,
		     COUNT( * ) NumAppts,
		     SUM( CASE WHEN JOINT_APPT_YN = 'Y' THEN 1 ELSE 0 END ) NumJointAppts
    FROM V_SCHED_APPT
      INNER JOIN PAT_ENC
	      ON V_SCHED_APPT.PAT_ENC_CSN_ID = PAT_ENC.PAT_ENC_CSN_ID
    WHERE PAT_ENC.ENC_CLOSED_YN = 'Y'
    GROUP BY V_SCHED_APPT.DEPARTMENT_ID,
             V_SCHED_APPT.PROV_NAME_WID
    ORDER BY NumAppts DESC,
             NumJointAppts DESC,
	  	       V_SCHED_APPT.DEPARTMENT_ID,
             V_SCHED_APPT.PROV_NAME_WID */