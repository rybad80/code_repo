/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that shows all actions patients take when completing their Welcome Check In workflows. 
   Only show actions where the workflow attempt was successful. For each action, display the 
   action type, subtype, outcome, action order in the workflow attempt, and instant. */


USE Caboodle_Aug

SELECT PatientApplicationActionFact.ActionType "Type",
       PatientApplicationActionFact.ActionSubType "Subtype",
       PatientApplicationActionFact.ActionOutcome "Outcome",
       PatientApplicationActionFact.ActionOrderInAttempt "Order in Attempt",
       PatientApplicationActionFact.ActionInstant "Instant"
  FROM PatientApplicationActionFact
    INNER JOIN PatientWorkflowAttemptFact
      ON PatientApplicationActionFact.PatientWorkflowAttemptKey = PatientWorkflowAttemptFact.PatientWorkflowAttemptKey
  WHERE PatientWorkflowAttemptFact.AttemptSuccessful = 1
    AND PatientWorkflowAttemptFact.WorkflowSubType = 'Welcome Check In'