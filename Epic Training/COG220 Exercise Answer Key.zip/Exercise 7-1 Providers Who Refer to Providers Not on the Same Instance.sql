/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization would like to reduce the number of referrals that originate from 
   internal providers and are sent to providers not on your instance of Epic. Write a 
   report to find those referrals. For each referral, display the name of the referring
   provider, the primary procedure, the referral's status, and whether the referral is 
   considered leaked.
   If you have time, group those referrals by referring provider and primary procedure.
   Display provider's name, the procedure name, the number of referrals, the number of 
   those referrals that are in a status of Authorized, and the number of those referrals
   that are considered leaked. */

USE Caboodle_Aug

SELECT ProviderDim.Name Provider,
       ProcedureDim.Name ProcedureName,
	   ReferralFact.IsLeaked_YesNo LeakedYn,
	   ReferralFact.Status Status
  FROM ReferralFact
    INNER JOIN ProviderDim
	  ON ReferralFact.ReferredByProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
	INNER JOIN ProcedureDim
	  ON ReferralFact.PrimaryProcedureDurableKey = ProcedureDim.DurableKey AND ProcedureDim.IsCurrent = 1
  WHERE	ReferralFact.Class = 'Outgoing'

/* If you have time
SELECT MAX( ProviderDim.Name ) Provider,
       MAX( ProcedureDim.Name ) ProcedureName,
       SUM( ReferralFact.Count) NumberOfReferrals,
	   SUM( CASE WHEN ReferralFact.Status = 'Authorized' THEN 1 ELSE 0 END ) NumberOfAuthorizedReferrals,
	   SUM( ReferralFact.IsLeaked ) NumberOfLeakedReferrals
  FROM ReferralFact
    INNER JOIN ProviderDim
	  ON ReferralFact.ReferredByProviderDurableKey = ProviderDim.DurableKey AND ProviderDim.IsCurrent = 1
	INNER JOIN ProcedureDim
	  ON ReferralFact.PrimaryProcedureDurableKey = ProcedureDim.DurableKey AND ProcedureDim.IsCurrent = 1
  WHERE	ReferralFact.Class = 'Outgoing'
  GROUP BY ReferralFact.ReferredByProviderDurableKey,
           ReferralFact.PrimaryProcedureDurableKey */