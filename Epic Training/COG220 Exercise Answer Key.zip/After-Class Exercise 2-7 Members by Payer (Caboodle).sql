/* © 2018-2023 Epic Systems Corporation. Confidential.
   For each payer, display the number of patients in your system who have an effective coverage with the payer. 
   Do not include payers who have no patients with effective coverages. */

/* NOTE: This will only return managed care coverages, which is a significant limitation. 
         The Clarity answer would include all coverages. */

Use Caboodle_Aug

SELECT MAX( CoverageDim.PayorName ) PayerName,
       COUNT( DISTINCT EligibilityEventFact.PatientDurableKey ) NumPats
  FROM EligibilityEventFact
	  INNER JOIN DateDim StartDate
	    ON EligibilityEventFact.StartDateKey = StartDate.DateKey
	  INNER JOIN DateDim EndDate
	    On EligibilityEventFact.EndDateKey = EndDate.DateKey
	  INNER JOIN CoverageDim
	    ON EligibilityEventFact.CoverageKey = CoverageDim.CoverageKey
  WHERE StartDate.DateValue <= CURRENT_TIMESTAMP
    AND (EndDate.DateValue >= CURRENT_TIMESTAMP or EndDate.DateValue IS NULL)
  GROUP BY CoverageDim.PayorEpicId