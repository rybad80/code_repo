/* © 2018-2023 Epic Systems Corporation. Confidential.
   Fill in the Guarantor Name field on the (Handout) Registration Data on Patient Encounters. Additionally, 
   fill in the filter Personal/Family guarantor accounts in the Filters section. Update the query from the
   previous exercise to also display the guarantor name and filter to only include Personal/Family 
   guarantor accounts. */

USE Caboodle_Aug

SELECT PatientDim.Name,
       PatientDim.PrimaryMrn,
       GuarantorDim.Name
  FROM BillingAccountFact
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN DateDim
  	  ON BillingAccountFact.AccountCreateDateKey = DateDim.DateKey
    INNER JOIN PatientDim
      ON BillingAccountFact.PatientDurableKey = PatientDim.DurableKey AND PatientDim.IsCurrent = 1
    INNER JOIN GuarantorDim
      ON BillingAccountFact.GuarantorDurableKey = GuarantorDim.DurableKey AND GuarantorDim.IsCurrent = 1
  WHERE DepartmentDim.ServiceAreaEpicId = '10'
    AND DateDim.DateValue >= DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) )
      -- the filter against CURRENT_TIMESTAMP is only necessary in the training environment that has future-dated data
    AND DateDim.DateValue <= CURRENT_TIMESTAMP
    AND GuarantorDim.AccountType = 'Personal/Family'