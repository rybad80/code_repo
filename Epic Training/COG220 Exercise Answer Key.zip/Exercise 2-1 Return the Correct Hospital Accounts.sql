/* © 2018-2023 Epic Systems Corporation. Confidential.
   Fill in the department and creation date filters in the Filters section of the (Handout) Registration Data on Patient Encounters. 
   Write a SQL query that returns hospital accounts created in the EHS Service Area in the past year. Display the 
   lookup column for patient information in the SELECT clause. */

USE Caboodle_Aug

SELECT BillingAccountFact.PatientDurableKey
  FROM BillingAccountFact
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
    INNER JOIN DateDim
  	  ON BillingAccountFact.AccountCreateDateKey = DateDim.DateKey
  WHERE DepartmentDim.ServiceAreaEpicId = '10'
    AND DateDim.DateValue >= DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) )
      -- the filter against CURRENT_TIMESTAMP is only necessary in the training environment that has future-dated data
    AND DateDim.DateValue <= CURRENT_TIMESTAMP