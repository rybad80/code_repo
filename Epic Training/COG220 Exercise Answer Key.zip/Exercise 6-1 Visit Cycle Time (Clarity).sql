/* © 2018-2023 Epic Systems Corporation. Confidential.
   Your organization would like to reduce the length of time patients must wait between 
   checking in and being roomed for office visits. For each visit with a visit type of 
   office visit, display the department, the primary visit provider, and the wait time 
   between check-in and rooming in minutes.
   If you have time, display the average wait time and number of visits for each primary 
   provider in each department for office visits. */

USE Clarity_Aug

SELECT V_SCHED_APPT.DEPARTMENT_NAME Department,
       V_SCHED_APPT.PROV_NAME_WID Provider,
       V_SCHED_APPT.TIME_TO_ROOM_MINUTES MinutesToRoom
  FROM V_SCHED_APPT
        -- V_SCHED_APPT.PRC_ID is a varchar column, and 1004 is the value for office visit
  WHERE V_SCHED_APPT.PRC_ID = '1004'

/* If you have time
SELECT MAX( V_SCHED_APPT.DEPARTMENT_NAME) Department,
       MAX( V_SCHED_APPT.PROV_NAME_WID ) Provider,
       AVG( V_SCHED_APPT.TIME_TO_ROOM_MINUTES ) AvgMinutesToRoom,
       COUNT( * ) NumVisits
  FROM V_SCHED_APPT
        -- V_SCHED_APPT.PRC_ID is a varchar column, and 1004 is the value for office visit
  WHERE V_SCHED_APPT.PRC_ID = '1004'
  GROUP BY V_SCHED_APPT.DEPARTMENT_ID,
           V_SCHED_APPT.PROV_ID
  ORDER BY Department,
		   Provider */