/* © 2018-2023 Epic Systems Corporation. Confidential.
   Write a report that displays the percentage of referrals that have at least one scheduled encounter. Compare the percentage 
   for referrals that were created through an order against the percentage for referrals that were not created through an order. */

USE Caboodle_Aug

SELECT ReferralFact.GeneratedByOrder_YesNo GeneratedByOrder,
       SUM( ReferralFact.LinkedToAnEncounter ) * 1.0 / SUM( ReferralFact.Count ) * 100 CompletionPercent
  FROM ReferralFact
        -- filter out deleted and referential integrity rows
  WHERE ReferralFact.Count = 1 AND ReferralFact._IsInferred = 0
  GROUP BY ReferralFact.GeneratedByOrder_YesNo