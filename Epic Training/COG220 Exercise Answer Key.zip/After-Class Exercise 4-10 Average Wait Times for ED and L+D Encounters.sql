/* © 2018-2023 Epic Systems Corporation. Confidential.
   Report on the average difference in minutes between a patient's arrival in ED or L&D units and when 
   the patient was bedded. Display the average wait times for the ED and L&D encounters separately. */

USE Clarity_Aug

SELECT 'ED'	EncounterType,
       AVG( DATEDIFF( MINUTE, PAT_ENC_HSP.ADT_ARRIVAL_TIME, PAT_ENC_HSP.HOSP_ADMSN_TIME ) ) AvgWaitTimeInMinutes
  FROM PAT_ENC_HSP
  WHERE PAT_ENC_HSP.ED_EPISODE_ID IS NOT NULL

UNION ALL

SELECT 'L&D',
       AVG( DATEDIFF( MINUTE, PAT_ENC_HSP.ADT_ARRIVAL_TIME, PAT_ENC_HSP.HOSP_ADMSN_TIME) )
  FROM PAT_ENC_HSP
  WHERE	PAT_ENC_HSP.LABOR_STATUS_C IS NOT NULL