--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your denials supervisor wants to identify which insurers sent
denials greater than $200 in Q1 of 2019 (January - March).
- The consumer is only interested in BDC-level data
- Display the date that each denial was received and completed
- Display the billed amount, the allowed amount, and the denied amount 
- The report should be organized by external remittance code, then by payer
- Only denials should be included, not correspondences or remarks
*/


 USE Caboodle_Aug

SELECT CoverageDim.PayorName						"Payer",
       RemittanceCodeDim.ExternalRemittanceCode		"External Remit Code"	,
       credate.DisplayString						"Create Date",
       recdate.DisplayString						"Received Date",
       compdate.DisplayString						"Completed Date",
       BillingDenialFact.BilledAmount				"Billed Amount",
       BillingDenialFact.AllowedAmount				"Allowed Amount",
       BillingDenialFact.DeniedAmount				"Denied Amount",
       BillingDenialFact.BillingSystemType			"Billing System"
    FROM BillingDenialFact
      INNER JOIN DateDim credate
        ON BillingDenialFact.CreateDateKey = credate.DateKey
      INNER JOIN DateDim recdate
        ON BillingDenialFact.ReceiveDateKey = recdate.DateKey
      INNER JOIN DateDim compdate
        ON BillingDenialFact.CompleteDateKey = compdate.DateKey
      INNER JOIN RemittanceCodeDim
        ON BillingDenialFact.RemittanceCodeKey = RemittanceCodeDim.RemittanceCodeKey
      INNER JOIN CoverageDim
        ON BillingDenialFact.DenialPayerKey = CoverageDim.CoverageKey
    WHERE recdate.DateValue >= '01 JAN 2019'
      AND recdate.DateValue < '01 APR 2019'
      AND BillingDenialFact.DeniedAmount > 200
    ORDER BY RemittanceCodeDim.ExternalRemittanceCode,
             CoverageDim.PayorName