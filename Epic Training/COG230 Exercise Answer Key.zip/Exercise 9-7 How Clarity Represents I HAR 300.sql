--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
In this exercise, you will investigate how HSP_ACCT_CVG_LIST 
reflects the information held in I HAR 300.
*/

USE Clarity_Aug

SELECT cvg1.HSP_ACCOUNT_ID,
       cvg1.LINE,
	   cvg1.COVERAGE_ID,
	   CLARITY_EPM.PAYOR_NAME
  FROM HSP_ACCT_CVG_LIST cvg1
      --Only include HARs with more than one coverage
    INNER JOIN HSP_ACCT_CVG_LIST cvg2
      ON cvg1.HSP_ACCOUNT_ID = cvg2.HSP_ACCOUNT_ID
        AND cvg2.LINE = 2
    INNER JOIN HSP_ACCOUNT
      ON cvg1.HSP_ACCOUNT_ID = HSP_ACCOUNT.HSP_ACCOUNT_ID
    INNER JOIN COVERAGE 
      ON cvg1.COVERAGE_ID = COVERAGE.COVERAGE_ID
    INNER JOIN CLARITY_EPM
      ON COVERAGE.PAYOR_ID = CLARITY_EPM.PAYOR_ID
    -- 40 is the value for voided, which are basically deleted HARs
  WHERE HSP_ACCOUNT.ACCT_BILLSTS_HA_C <> 40
  ORDER BY cvg1.HSP_ACCOUNT_ID,
           cvg1.LINE