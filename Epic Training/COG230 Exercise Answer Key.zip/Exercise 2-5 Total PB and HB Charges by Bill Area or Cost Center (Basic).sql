--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Use Caboodle to write a query to find total charges in both 
Professional Billing and Hospital Billing, organized by bill area 
or cost center and performing provider.

- Find transactions posted between 1/1/2017 and 1/1/2019. 
- Display the name of the billing area or cost center, the service provider,
and total charges.
- Order by bill area or cost center name and service provider. 
- Only show rows with amounts greater than zero.
*/

USE Caboodle_Aug

SELECT CASE	WHEN BillingTransactionFact.BillAreaKey <> -2 THEN BillAreaDim.BillAreaName
            WHEN BillingTransactionFact.CostCenterKey <> -2 THEN CostCenterDim.Name
			ELSE '*Not Applicable' END													"Bill Area or Cost Center",
	   ProviderDim.Name																	"Service Provider",
	   BillingTransactionFact.ChargeAmount												"Total Charges"
FROM BillingTransactionFact
  INNER JOIN DateDim DateDim
    ON BillingTransactionFact.PostDateKey = DateDim.DateKey
  INNER JOIN ProviderDim
    ON BillingTransactionFact.ServiceProviderDurableKey = ProviderDim.DurableKey
      AND ProviderDim.IsCurrent = 1
  INNER JOIN BillAreaDim
    ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
  INNER JOIN CostCenterDim
    ON BillingTransactionFact.CostCenterKey = CostCenterDim.CostCenterKey
WHERE DateDim.DateValue >= '01 JAN 2017'
  AND DateDim.DateValue < '01 JAN 2019'
  AND BillingTransactionFact.ChargeAmount > 0
ORDER BY 
	"Bill Area or Cost Center"
	,ProviderDim.Name