--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your denials supervisor wants to identify which insurers sent
denials greater than $200 in Q1 of 2019 (January - March).
- The consumer is only interested in BDC-level data
- Display the date that each denial was received and completed
- Display the billed amount, the allowed amount, and the denied amount 
- The report should be organized by external remittance code, then by payer
*/


USE Caboodle_Aug

SELECT CoverageDim.PayorName			"Payer"
	,'external remit code'				"External Remit Code"	
	,'received date'					"Received Date"
	,'completed date'					"Completed Date"
	,'Billed Amount'					"Billed Amount"
	,'Allowed Amount'					"Allowed Amount"
	,'Denied Amount'					"Denied Amount"
	,BillingSystemType
FROM BillingDenialFact
  INNER JOIN DateDim recdate
    ON 'receive date join condition'
  INNER JOIN DateDim compdate
    ON 'complete date join condition'
  INNER JOIN 'remittance code table'
    ON 'join condition'
  INNER JOIN CoverageDim
    ON BillingDenialFact.DenialPayerKey = CoverageDim.CoverageKey
WHERE recdate.DateValue >= '01 JAN 2019'
  AND recdate.DateValue < '01 APR 2019'
  AND BillingDenialFact.DeniedAmount > 200
ORDER BY 'external remittance code',
         CoverageDim.PayorName