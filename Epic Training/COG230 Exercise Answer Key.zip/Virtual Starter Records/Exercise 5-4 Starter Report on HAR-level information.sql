--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a query to display all HARs in the EHS Service Area [10] with a 
primary payer of BCBS In State [200001]. Display the HAR�s ID, whether it is an HB or 
PB HAR, the guarantor�s current name, and the total balance on the HAR. 
Use either Clarity or Caboodle.
*/

USE Caboodle_Aug

SELECT BillingAccountFact.AccountEpicId			"HAR ID",
	   'Billing System Type'					"Hospital/Professional?",
	   'guarantor name'							"Guarantor",
	   'account balance'						"Total Balance"
  FROM BillingAccountFact
    INNER JOIN CoverageDim
      ON BillingAccountFact.PrimaryCoverageKey = CoverageDim.CoverageKey
	--guarantor join
    INNER JOIN 'guarantor table'
      ON 'join condition'
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
  WHERE 'payer identifier' = '200001'
    AND 'service area identifier' = '10'


USE Clarity_May

SELECT HSP_ACCOUNT.HSP_ACCOUNT_ID						"HAR ID",
	   'Billing System type'							"Hospital/Professional?",
	   'guarantor name'									"Guarantor",
	    'account balance'								"Total Balance" 
  FROM HSP_ACCOUNT
    --guarantor join
	INNER JOIN 'guarantor table'
      ON 'join condition'
    -- join to HSP_ACCT_SBO and HAR type ZC_ table
	INNER JOIN HSP_ACCT_SBO
      ON 'join condition'
    INNER JOIN ZC_SBO_HAR_TYPE
      ON 'join condition'
  WHERE HSP_ACCOUNT.PRIMARY_PAYOR_ID = 200001
    AND HSP_ACCOUNT.SERV_AREA_ID = 10