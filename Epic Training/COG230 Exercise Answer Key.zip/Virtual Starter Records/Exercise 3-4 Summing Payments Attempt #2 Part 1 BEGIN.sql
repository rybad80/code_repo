--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your organization�s billing BID group has an old report in 
CLARITY_TDL_TRAN that they�re re-writing in Caboodle. The report 
sums all PB transactions grouped by bill area with separate 
columns that sum amounts for the charges, payments, debit adjustments, 
and credit adjustments. Your coworker has started this query 
but has not finished it.
*/

/*
Use this list of detail types to cut and paste into the appropraiate 
column in the SELECT clause:
New Charge
New Payment
New Debit Adjustment
New Credit Adjustment
Payment Reversal
Credit Adjustment Reversal
Void Charge
Void Payment
Void Debit Adjustment
Void Credit Adjustment
Match/Unmatch (Charge->Payment)
Match/Unmatch (Charge->Credit Adjustment)
Match/Unmatch (Debit Adjustment->Payment)
Match/Unmatch (Debit Adjustment->Credit Adjustment)
Match/Unmatch (Credit Adjustment->Charge)
Match/Unmatch (Credit Adjustment->Debit Adjustment)
Match/Unmatch (Payment->Charge)
Match/Unmatch (Payment->Debit Adjustment)
*/

USE Caboodle_Aug

SELECT MAX( BillAreaDim.BillAreaName )																														"Bill Area",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN --Choose the appropriate detail types for charges 
	             THEN Amount
                 ELSE 0 END )																																"Charges Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN --Choose the appropriate detail types for payments
                 THEN Amount
				 ELSE 0 END )																																"Payments Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN --Choose the appropriate detail types for debit adjustments
                 THEN Amount
			     ELSE 0 END )																																"Debit Adjustments Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN --Choose the appropriate detail types for credit adjustments
                 THEN Amount
                 ELSE 0
                 END)																																		"Credit Adjustments Manually",
       SUM( BillingTransactionFact.Amount )																													"Net"
  FROM BillingTransactionFact
    INNER JOIN BillAreaDim
      ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
    INNER JOIN DateDim
  	  ON BillingTransactionFact.PostDateKey = DateDim.DateKey
  WHERE BillingTransactionFact.BillingSystemType = 'Professional'
    AND DateDim.DateValue > DATEADD ( YYYY, -5, CURRENT_TIMESTAMP )
  GROUP BY BillingTransactionFact.BillAreaKey

