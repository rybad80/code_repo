--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Display all stop bills, DNB checks, and billing indicators on all HARs that were discharged in 2016
Display the HAR�s ID and discharge date
One column that displays the type
One column for the extra data
	For each stop bill, display its reason
	For each DNB check, display the name of the LPP record that triggered it
	For each billing indicator, display its type
*/

USE Clarity_Aug

SELECT HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID			"HAR ID",
       CAST(HSP_ACCOUNT.DISCH_DATE_TIME AS DATE)	"Discharge Date",
       ZC_HX_DNB_SB.NAME							"Type",
       CASE HSP_ACCT_DNB_SB_HX.HX_DNB_SB_C
	     WHEN 1 THEN 'display column'
		 WHEN 2 THEN 'display column'
		 WHEN 4 THEN 'display column'
		 ELSE 'Unknown' END							"Reason"
  FROM HSP_ACCT_DNB_SB_HX
    INNER JOIN HSP_ACCOUNT
      ON HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID = HSP_ACCOUNT.HSP_ACCOUNT_ID
    INNER JOIN ZC_HX_DNB_SB
      ON 'join condition'
    LEFT OUTER JOIN CLARITY_LPP
      ON 'join condition'
    LEFT OUTER JOIN ZC_STOPBILL_RSN_HA
      ON 'join condition'
    LEFT OUTER JOIN ZC_BILL_IND
      ON 'join condition'
  WHERE YEAR(HSP_ACCOUNT.DISCH_DATE_TIME) = 2016