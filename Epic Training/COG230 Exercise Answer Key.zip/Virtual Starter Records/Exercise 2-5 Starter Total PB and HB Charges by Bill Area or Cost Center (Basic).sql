--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Use Caboodle to write a query to find total charges in both 
Professional Billing and Hospital Billing, organized by bill area 
or cost center and performing provider.

- Find transactions posted between 1/1/2017 and 1/1/2019. 
- Display the name of the billing area or cost center, the service provider,
and total charges.
- Order by bill area or cost center name and service provider. 
- Only show rows with amounts greater than zero.
*/

USE Caboodle_Aug

SELECT
	CASE
		WHEN tx.BillAreaKey <> -2 THEN 'display column'
		WHEN tx.CostCenterKey <> -2 THEN 'display column'
		ELSE '*Not Applicable'
	END								"Bill Area or Cost Center"
	,'service provider name'		"Service Provider"
	,'total charges'				"Total Charges"
FROM 
	BillingTransactionFact tx
	INNER JOIN DateDim ddim
		ON tx.PostDateKey = ddim.DateKey
	INNER JOIN 'provider table'
		ON 'join condition'
	INNER JOIN 'bill area'
		ON 'join condition'
	INNER JOIN 'cost center'
		ON 'join condition'
WHERE 
	'post date filter'
	AND	tx.ChargeAmount > 0

ORDER BY 
	"Bill Area or Cost Center"
	,'provider name'