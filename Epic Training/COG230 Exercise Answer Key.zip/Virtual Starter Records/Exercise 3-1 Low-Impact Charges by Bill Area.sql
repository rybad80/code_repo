--� 2018 - 2023 Epic Systems Corporation. Confidential.

/* 
Display one row per charge. Include only charges with an original posted amount 
of less than $20, and do not include voided charges. 
Display the original amount, the outstanding amount, 
the name of the bill area, and the name of the payer. 
*/

USE Clarity_Aug

SELECT ARPB_TRANSACTIONS.TX_ID,
       'Original Amount'					  "Original Amount",
       'Outstanding Amount'					  "Outstanding Amount",
       BILL_AREA.RECORD_NAME                  "Bill Area",
       CLARITY_EPM.PAYOR_NAME                 "Payer"
  FROM ARPB_TRANSACTIONS 
    LEFT OUTER JOIN BILL_AREA 
      ON ARPB_TRANSACTIONS.BILL_AREA_ID = BILL_AREA.BILL_AREA_ID
    LEFT OUTER JOIN CLARITY_EPM 
      ON ARPB_TRANSACTIONS.PAYOR_ID = CLARITY_EPM.PAYOR_ID
  WHERE 'Charges Only' 
    AND 'Original Amount of the Transaction is under $20'
    AND 'The transaction is not voided'


USE Caboodle_Aug

SELECT BillingTransactionFact.ProfessionalBillingTransactionEpicId,
      'Original Amount'												"Original Amount",
      'Outstanding Amount'										    "Outstanding Amount",
       BillAreaDim.BillAreaName										"Bill Area",
       CoverageDim.PayorName										"PayorName"
  FROM BillingTransactionFact
    INNER JOIN BillAreaDim 
      ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
    INNER JOIN CoverageDim 
      ON BillingTransactionFact.CurrentPayerKey = CoverageDim.CoverageKey
  WHERE 'PB Only'
    AND 'Charges Only'
    AND BillingTransactionFact.TransactionDetailType LIKE 'new%' -- This filters to 1 row per transaction. More on detail types to come later in the chapter.
    AND 'Original Amount of the Transaction is under $20'
    AND 'The transaction is not voided'