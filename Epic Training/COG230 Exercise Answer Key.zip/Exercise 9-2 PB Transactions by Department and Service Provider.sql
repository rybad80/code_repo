--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a Clarity report showing transaction activity in the last five years, 
grouped by department and service provider. Display individual columns 
for charges, payments, debit adjustments, credit adjustments, and net amounts.
Display the department and service provider names.
*/

USE Clarity_Aug

SELECT MAX( CLARITY_DEP.DEPARTMENT_NAME)				"Department",
	   MAX( CLARITY_SER.PROV_NAME)						"Service Provider",
	   SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE IN ( 1,10 ) 
	             THEN ACTIVE_AR_AMOUNT
	             ELSE 0 END )								"Charges",
	   SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE IN ( 2,5,11,20,22,32,33 ) 
	             THEN ACTIVE_AR_AMOUNT
				 ELSE 0 END )								"Payments",
	   SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 3, 12 )
	             THEN CLARITY_TDL_TRAN.ACTIVE_AR_AMOUNT
				 ELSE 0 END )								"Debit Adjustments",
	   SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 4, 6, 13, 21, 23, 30, 31)
	             THEN CLARITY_TDL_TRAN.ACTIVE_AR_AMOUNT
				 ELSE 0 END )								"Credit Adjustments",
	   SUM( CLARITY_TDL_TRAN.ACTIVE_AR_AMOUNT )					"Net"
  FROM CLARITY_TDL_TRAN
    LEFT OUTER JOIN CLARITY_SER
      ON CLARITY_TDL_TRAN.PERFORMING_PROV_ID = CLARITY_SER.PROV_ID
    LEFT OUTER JOIN CLARITY_DEP
      ON CLARITY_TDL_TRAN.DEPT_ID = CLARITY_DEP.DEPARTMENT_ID
  WHERE CLARITY_TDL_TRAN.DETAIL_TYPE < 40
    AND CLARITY_TDL_TRAN.POST_DATE > DATEADD( YYYY, -5, CURRENT_TIMESTAMP )
  GROUP BY CLARITY_TDL_TRAN.DEPT_ID,
           CLARITY_TDL_TRAN.PERFORMING_PROV_ID