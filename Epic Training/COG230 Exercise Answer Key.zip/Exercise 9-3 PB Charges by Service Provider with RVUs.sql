--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a Clarity report for finance managers to use monthly to review RVU 
information per provider to help determine compensation. Base your report on 
professional billing transactions. Group the query by the month and year in 
which the transaction was posted, and by service provider, displaying the 
provider's name.

For each provider, display the total amount of charges posted for the month, 
total RVUs, and total Work, Overhead, and Malpractice RVUs. Assume you would
like to report on Relative Value Units from the procedure (EAP) master file.
*/

USE Clarity_Aug

SELECT YEAR( ACTIVITY_DATE )		"Year",
	   MONTH( ACTIVITY_DATE )		"Month",
	   SERVICE_PROV_NAME_WITH_ID	"Service Provider",
	   SUM( AMOUNT) 				"Total Charges",
	   SUM( RVU_TOTAL )				"Total RVUs",
	   SUM( RVU_WORK )				"Work RVUs",
	   SUM( RVU_OVERHEAD )			"Overhead RVUs",
	   SUM( RVU_MALPRACTICE )		"Malpractice RVUs"
  FROM V_ARPB_RVU_DATA
  GROUP BY YEAR( ACTIVITY_DATE ),
           MONTH( ACTIVITY_DATE ),
           SERVICE_PROV_NAME_WITH_ID
  ORDER BY YEAR( ACTIVITY_DATE ),
           MONTH( ACTIVITY_DATE )