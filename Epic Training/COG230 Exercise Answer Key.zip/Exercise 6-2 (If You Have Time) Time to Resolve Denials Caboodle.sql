--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your denials supervisor wants to identify which insurers sent
denials greater than $200 in Q1 of 2019 (January - March).
- The consumer is only interested in BDC-level data
- Display the date that each denial was received and completed
- Display the billed amount, the allowed amount, and the denied amount 
- The report should be organized by external remittance code, then by payer
- Only denials should be included, not correspondences or remarks

Open Days: If the denial is closed, display the length of time it was open. 
   If the denial is open, calculate the amount of time it has been open.
Resolve Reason: If the denial is unresolved, display "unresolved". 
   If the Denial is resolved, display the resolution category.
*/


 USE Caboodle_Aug

SELECT CoverageDim.PayorName						"Payer",
       RemittanceCodeDim.ExternalRemittanceCode		"External Remit Code"	,
       credate.DisplayString						"Create Date",
       recdate.DisplayString						"Received Date",
       compdate.DisplayString						"Completed Date",
       BillingDenialFact.BilledAmount				"Billed Amount",
       BillingDenialFact.AllowedAmount				"Allowed Amount",
       BillingDenialFact.DeniedAmount				"Denied Amount",
       BillingDenialFact.BillingSystemType			"Billing System"

-- If You Have Time section

      ,BillingDenialFact.Status
      ,CASE BillingDenialFact.IsOpen WHEN 0 THEN 'Closed'
                                     WHEN 1 THEN 'Open'
                                     END																"Open/Closed"
      ,CASE WHEN BillingDenialFact.IsOpen = 1 THEN DATEDIFF( D, CREDATE.DATEVALUE, CURRENT_TIMESTAMP )
	        WHEN BillingDenialFact.IsOpen = 0 THEN BillingDenialFact.DaysToClose
			END																							"Days Open"
      ,CASE	WHEN BillingDenialFact.ResolutionCategory LIKE '*%'	THEN 'Unresolved'
	        ELSE BillingDenialFact.ResolutionCategory
			END																							"Resolution"

    FROM BillingDenialFact
      INNER JOIN DateDim credate
        ON BillingDenialFact.CreateDateKey = credate.DateKey
      INNER JOIN DateDim recdate
        ON BillingDenialFact.ReceiveDateKey = recdate.DateKey
      INNER JOIN DateDim compdate
        ON BillingDenialFact.CompleteDateKey = compdate.DateKey
      INNER JOIN RemittanceCodeDim
        ON BillingDenialFact.RemittanceCodeKey = RemittanceCodeDim.RemittanceCodeKey
      INNER JOIN CoverageDim
        ON BillingDenialFact.DenialPayerKey = CoverageDim.CoverageKey
    WHERE recdate.DateValue >= '01 JAN 2019'
      AND recdate.DateValue < '01 APR 2019'
      AND BillingDenialFact.DeniedAmount > 200
    ORDER BY RemittanceCodeDim.ExternalRemittanceCode,
             CoverageDim.PayorName