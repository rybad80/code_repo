--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Find the variance using the allowed amount (not the paid amount), grouped by 
payer and contract, for services within the last year. Write one query for 
Hospital Billing and one for Professional Billing. For Professional Billing, 
use V_ARPB_REIMBURSEMENT. For Hospital Billing, use V_ARHB_VARIANCE_SUMMARY 
and the discharge date as the service date. Display the absolute variance, 
the payer name, and the contract name. Only show rows with non-zero variances.
*/

--Professional Billing
USE Clarity_Aug

SELECT PAYOR_NM_WID,
       CONTRACT_NM_WID,
	   SUM( ABS( COALESCE( EXPECT_REIMB_AMOUNT - EOB_ALLOWED_AMOUNT, 0 ) ) )		"Variance"
  FROM V_ARPB_REIMBURSEMENT
  WHERE SERVICE_DTTM > DATEADD(M, -12, CURRENT_TIMESTAMP)
    AND EXPECT_REIMB_AMOUNT - EOB_ALLOWED_AMOUNT <> 0
  GROUP BY PAYOR_NM_WID,
           CONTRACT_NM_WID



--Hospital Billing
USE Clarity_Aug

SELECT BUCKET_PAYER_ID,
       MAX( BUCKET_PAYER_NAME ),
	   CONTRACT_ID,
	   MAX( CONTRACT_NAME ),
	   SUM( ABS( COALESCE( EXPECTED_ALLOWED_AMT - PAYER_ALLOWED_AMT, 0 ) ) )		"Variance"
  FROM V_ARHB_VARIANCE_SUMMARY
  WHERE DISCH_DATE > DATEADD(M, -12, CURRENT_TIMESTAMP)
    AND EXPECTED_ALLOWED_AMT - PAYER_ALLOWED_AMT <> 0
  GROUP BY BUCKET_PAYER_ID,
           CONTRACT_ID