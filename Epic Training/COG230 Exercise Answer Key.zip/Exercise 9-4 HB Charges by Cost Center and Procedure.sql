--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a Clarity report on charges by cost center and procedure. 
You will organize the report by cost center, displaying the cost center 
name, and by procedure, displaying the procedure name and external code. 
Filter to only return charges that were posted within the first quarter of 2018
and display the transaction's post date and charge amount.
*/

USE Clarity_Aug

SELECT HSP_TRANSACTIONS.PROCEDURE_DESC			"Procedure",
       CLARITY_EAP.PROC_CODE					"Procedure Code",
       HSP_TRANSACTIONS.TX_POST_DATE			"Post Date",
       coalesce(HSP_TRANSACTIONS.TX_AMOUNT, 0)	"Amount",
       CL_COST_CNTR.COST_CENTER_NAME			"Cost Center"
  FROM HSP_TRANSACTIONS
    INNER JOIN CL_COST_CNTR
      ON HSP_TRANSACTIONS.COST_CNTR_ID = CL_COST_CNTR.COST_CNTR_ID
    INNER JOIN CLARITY_EAP
      ON HSP_TRANSACTIONS.PROC_ID = CLARITY_EAP.PROC_ID
  WHERE HSP_TRANSACTIONS.TX_TYPE_HA_C = 1 --Charge
    AND	HSP_TRANSACTIONS.TX_POST_DATE >= '01 JAN 2018'
    AND	HSP_TRANSACTIONS.TX_POST_DATE < '01 APR 2018'
  ORDER BY CL_COST_CNTR.COST_CENTER_NAME
	