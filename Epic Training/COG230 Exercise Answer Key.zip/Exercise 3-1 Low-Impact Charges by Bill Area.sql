--� 2018 - 2023 Epic Systems Corporation. Confidential.

/* 
Display one row per charge. Include only charges with an original posted amount 
of less than $20, and do not include voided charges. 
Display the original amount, the outstanding amount, 
the name of the bill area, and the name of the payer. 
*/

USE Clarity_Aug

SELECT ARPB_TRANSACTIONS.TX_ID,
       ARPB_TRANSACTIONS.AMOUNT               "Original Amount",
       ARPB_TRANSACTIONS.OUTSTANDING_AMT      "Outstanding Amount",
       BILL_AREA.RECORD_NAME                  "Bill Area",
       CLARITY_EPM.PAYOR_NAME                 "Payer"
  FROM ARPB_TRANSACTIONS 
    LEFT OUTER JOIN BILL_AREA 
      ON ARPB_TRANSACTIONS.BILL_AREA_ID = BILL_AREA.BILL_AREA_ID
    LEFT OUTER JOIN CLARITY_EPM 
      ON ARPB_TRANSACTIONS.PAYOR_ID = CLARITY_EPM.PAYOR_ID
  WHERE ARPB_TRANSACTIONS.TX_TYPE_C = 1 
    AND ARPB_TRANSACTIONS.AMOUNT < 20
    AND ARPB_TRANSACTIONS.VOID_DATE IS NULL


USE Caboodle_Aug

SELECT BillingTransactionFact.ProfessionalBillingTransactionEpicId,
       BillingTransactionFact.Amount								"Original Amount",
       BillingTransactionFact.OutstandingAmount						"Outstanding Amount",
       BillAreaDim.BillAreaName										"Bill Area",
       CoverageDim.PayorName										"PayorName"
  FROM BillingTransactionFact
    INNER JOIN BillAreaDim 
      ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
    INNER JOIN CoverageDim 
      ON BillingTransactionFact.CurrentPayerKey = CoverageDim.CoverageKey
  WHERE BillingTransactionFact.BillingSystemType = 'Professional'
    AND BillingTransactionFact.TransactionType = 'Charge'
    AND BillingTransactionFact.TransactionDetailType LIKE 'new%'
    AND BillingTransactionFact.Amount < 20
    AND BillingTransactionFact.IsInactive = 0