--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Display all stop bills, DNB checks, and billing indicators on all HARs that were discharged in 2016
Display the HAR�s ID and discharge date
One column that displays the type
One column for the extra data
	For each stop bill, display its reason
	For each DNB check, display the name of the LPP record that triggered it
	For each billing indicator, display its type
*/

USE Clarity_Aug

SELECT HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID			"HAR ID",
	   CAST( HSP_ACCOUNT.DISCH_DATE_TIME AS DATE )	"Discharge Date",
	   ZC_HX_DNB_SB.NAME							"Type",
	   CASE HSP_ACCT_DNB_SB_HX.HX_DNB_SB_C 
	     WHEN 1 THEN CLARITY_LPP.LPP_NAME
		 WHEN 2 THEN ZC_STOPBILL_RSN_HA.NAME
		 WHEN 4 THEN ZC_BILL_IND.NAME
		 ELSE 'Unknown' END							"Reason"
  FROM HSP_ACCT_DNB_SB_HX
    INNER JOIN HSP_ACCOUNT
      ON HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID = HSP_ACCOUNT.HSP_ACCOUNT_ID
    INNER JOIN ZC_HX_DNB_SB
      ON HSP_ACCT_DNB_SB_HX.HX_DNB_SB_C = ZC_HX_DNB_SB.HX_DNB_SB_C
    LEFT OUTER JOIN CLARITY_LPP
      ON HSP_ACCT_DNB_SB_HX.DNB_RAP_LPP_ID = CLARITY_LPP.LPP_ID
    LEFT OUTER JOIN ZC_STOPBILL_RSN_HA
      ON HSP_ACCT_DNB_SB_HX.STOPBILL_RSN_HA_C = ZC_STOPBILL_RSN_HA.STOPBILL_RSN_HA_C
    LEFT OUTER JOIN ZC_BILL_IND
      ON HSP_ACCT_DNB_SB_HX.HX_BILLING_INDC_C = ZC_BILL_IND.BILL_IND_C
  WHERE YEAR( HSP_ACCOUNT.DISCH_DATE_TIME ) = 2016