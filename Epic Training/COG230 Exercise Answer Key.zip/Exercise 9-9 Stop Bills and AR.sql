--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a report to show how much stop bills are affecting AR: 
specifically, how big the accounts being delayed are, and how 
long they're being delayed. 
- Each stop bill placed on a hospital account should appear in its own row
- For each hospital account, the report should show the hospital account ID 
and name, the date and time the stop bill was placed on the account, the date 
and time the stop bill was removed from the account, and the total charges 
on the hospital account as of the date the stop bill was removed
*/

USE Clarity_Aug

SELECT HSP_ACCT_DNB_SB_HX.HX_DNB_SB_ADD_INST													"Stop Bill Added",
       HSP_ACCT_DNB_SB_HX.HX_DNB_SB_RMV_INST													"Stop Bill Removed",
       HSP_ACCOUNT.HSP_ACCOUNT_ID																"Hospital Account ID",
       HSP_ACCOUNT.HSP_ACCOUNT_NAME																"Hospital Account Name",
       COALESCE(HSP_HAR_SNAPSHOT.TOT_CHGS, 0)													"Total Charges at SB Removal",
       ZC_STOPBILL_RSN_HA.NAME																	"Stop Bill Reason",
       DATEDIFF(D,HSP_ACCT_DNB_SB_HX.HX_DNB_SB_ADD_INST,HSP_ACCT_DNB_SB_HX.HX_DNB_SB_RMV_INST)	"Days to Remove"
  FROM HSP_ACCT_DNB_SB_HX
    INNER JOIN HSP_ACCOUNT
      ON HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID = HSP_ACCOUNT.HSP_ACCOUNT_ID
    INNER JOIN HSP_HAR_SNAPSHOT
      ON HSP_ACCT_DNB_SB_HX.HSP_ACCOUNT_ID = HSP_HAR_SNAPSHOT.HSP_ACCOUNT_ID
    INNER JOIN ZC_STOPBILL_RSN_HA
      ON HSP_ACCT_DNB_SB_HX.STOPBILL_RSN_HA_C = ZC_STOPBILL_RSN_HA.STOPBILL_RSN_HA_C
  WHERE HSP_HAR_SNAPSHOT.SNAP_START_DATE <= HSP_ACCT_DNB_SB_HX.HX_DNB_SB_RMV_INST
    AND	HSP_HAR_SNAPSHOT.SNAP_END_DATE >= CAST( HSP_ACCT_DNB_SB_HX.HX_DNB_SB_RMV_INST AS DATE )