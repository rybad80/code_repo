--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*Use Clarity to determine how many estimates were created between January 1st 2019 and January 1st 2021. 
Group by estimate status, and be sure to count only estimates, not templates.*/


USE Clarity_Aug

SELECT ZC_STATUS_5.NAME					"Estimate Source",
	   COUNT(PR_EST_INFO.ESTIMATE_ID)	"Number of Estimates"
  FROM PR_EST_INFO
    INNER JOIN ZC_STATUS_5
  	  ON PR_EST_INFO.ESTIMATE_STATUS_C = ZC_STATUS_5.STATUS_5_C
    INNER JOIN ZC_TYPE_6
      ON PR_EST_INFO.TYPE_C = ZC_TYPE_6.TYPE_6_C
  WHERE PR_EST_INFO.ESTIMATE_CREATE_DT >= 'Jan 1, 2019' 
    AND PR_EST_INFO.ESTIMATE_CREATE_DT <= 'JAN 1, 2021'
    AND ZC_TYPE_6.NAME = 'Estimate'
  GROUP BY ZC_STATUS_5.NAME