--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
As part of a year-end review, find all active HB transactions posted 
in 2020 that were still active as of December 31, 2020. 

Display the transaction ID, post date, transaction amount, the name of the 
billing provider, and the name of the department the transaction was 
posted to. Sort the results by the post date of the transaction with 
the most recent listed first.
*/

USE Clarity_Aug

SELECT HSP_TRANSACTIONS.TX_ID, 
	   HSP_TRANSACTIONS.TX_POST_DATE,
	   HSP_TRANSACTIONS.TX_AMOUNT,
	   CLARITY_SER.PROV_NAME,
	   CLARITY_DEP.DEPARTMENT_NAME
  FROM HSP_TRANSACTIONS
    LEFT OUTER JOIN F_ARHB_INACTIVE_TX
      ON HSP_TRANSACTIONS.TX_ID = F_ARHB_INACTIVE_TX.TX_ID
    LEFT OUTER JOIN CLARITY_SER
      ON HSP_TRANSACTIONS.BILLING_PROV_ID = CLARITY_SER.PROV_ID
    LEFT OUTER JOIN CLARITY_DEP
      ON HSP_TRANSACTIONS.DEPARTMENT = CLARITY_DEP.DEPARTMENT_ID
  WHERE ( F_ARHB_INACTIVE_TX.TX_ID IS NULL OR F_ARHB_INACTIVE_TX.INACTIVE_DATE >= '1/1/2021' )
    AND ( HSP_TRANSACTIONS.TX_POST_DATE >= '1/1/2020' AND HSP_TRANSACTIONS.TX_POST_DATE < '1/1/2021' )
  ORDER BY HSP_TRANSACTIONS.TX_POST_DATE DESC