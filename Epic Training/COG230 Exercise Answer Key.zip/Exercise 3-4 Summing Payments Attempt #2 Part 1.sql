--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your organization�s billing BID group has an old report in 
CLARITY_TDL_TRAN that they�re re-writing in Caboodle. The report 
sums all PB transactions grouped by bill area with separate 
columns that sum amounts for the charges, payments, debit adjustments, 
and credit adjustments. Your coworker has started this query 
but has not finished it.
*/

USE Caboodle_Aug

SELECT MAX( BillAreaDim.BillAreaName )																														"Bill Area",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN ( 'New Charge','Void Charge' ) 
	             THEN Amount
                 ELSE 0 END )																																"Charges Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN ( 'New Payment','Void Payment', 'Payment Reversal',
	               'Match/Unmatch (Charge->Payment)', 'Match/Unmatch (Debit Adjustment->Payment)',
				   'Match/Unmatch (Payment->Charge)', 'Match/Unmatch (Payment->Debit Adjustment)' )  
                 THEN Amount
				 ELSE 0 END )																																"Payments Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN ( 'New Debit Adjustment', 'Void Debit Adjustment' )
                 THEN Amount
			     ELSE 0 END )																																"Debit Adjustments Manually",
       SUM( CASE WHEN BillingTransactionFact.TransactionDetailType IN ( 'New Credit Adjustment', 'Void Credit Adjustment', 'Credit Adjustment Reversal',
	          'Match/Unmatch (Charge->Credit Adjustment)', 'Match/Unmatch (Debit Adjustment->Credit Adjustment)',
			  'Match/Unmatch (Credit Adjustment->Charge)', 'Match/Unmatch (Credit Adjustment->Debit Adjustment)' )
                 THEN Amount
                 ELSE 0
                 END)																																		"Credit Adjustments Manually",
       SUM( BillingTransactionFact.Amount )																													"Net"
  FROM BillingTransactionFact
    INNER JOIN BillAreaDim
      ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
    INNER JOIN DateDim
  	  ON BillingTransactionFact.PostDateKey = DateDim.DateKey
  WHERE BillingTransactionFact.BillingSystemType = 'Professional'
    AND DateDim.DateValue > DATEADD ( YYYY, -5, CURRENT_TIMESTAMP )
  GROUP BY BillingTransactionFact.BillAreaKey

