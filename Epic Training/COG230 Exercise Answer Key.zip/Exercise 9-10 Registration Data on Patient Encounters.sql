--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a report that displays the encounter CSN, patient name, patient MRN, guarantor, and list of coverages in their 
filing order for each patient encounter with an encounter type of Office Visit in the EHS Service Area from the past year.
*/
   
USE Caboodle_Aug

SELECT VisitFact.EncounterEpicCSN	"CSN",
	   PatientDim.Name				"Patient Name",
	   PatientDim.PrimaryMrn		"Primary MRN",
	   GuarantorDim.Name			"Guarantor Name",
	   FirstCoverage.PayorName		"Primary Payer",
	   SecondCoverage.PayorName		"Secondary Payer"
  FROM VisitFact
    INNER JOIN PatientDim
      ON VisitFact.PatientDurableKey = PatientDim.DurableKey
        AND PatientDim.IsCurrent = 1
    INNER JOIN DateDim
      ON VisitFact.EncounterDateKey = DateDim.DateKey
    INNER JOIN BillingAccountEncounterMappingFact
      ON VisitFact.EncounterKey = BillingAccountEncounterMappingFact.EncounterKey
    INNER JOIN BillingAccountFact
      ON BillingAccountEncounterMappingFact.BillingAccountKey = BillingAccountFact.BillingAccountKey
    INNER JOIN GuarantorDim
      ON BillingAccountFact.GuarantorDurableKey = GuarantorDim.DurableKey
        AND GuarantorDim.IsCurrent = 1
    INNER JOIN CoverageDim FirstCoverage
      ON BillingAccountFact.PrimaryCoverageKey = FirstCoverage.CoverageKey
    INNER JOIN CoverageDim SecondCoverage
      ON BillingAccountFact.SecondCoverageKey = SecondCoverage.CoverageKey
    INNER JOIN DepartmentDim
      ON VisitFact.DepartmentKey = DepartmentDim.DepartmentKey
  WHERE DepartmentDim.ServiceAreaEpicId = '10'
    AND DateDim.DateValue > DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) ) 
    AND DateDim.DateValue <= CURRENT_TIMESTAMP
    AND VisitFact.EncounterType = 'Office Visit'
  ORDER BY 'Patient Name'


USE Clarity_Aug

SELECT PAT_ENC.PAT_ENC_CSN_ID									"CSN",
       PATIENT.PAT_NAME											"Patient Name",
	   PATIENT.PAT_MRN_ID										"Primary MRN",
	   ACCOUNT.ACCOUNT_NAME										"Guarantor Name",
	   V_COVERAGE_PAYOR_PLAN.PAYOR_NAME							"Payer Name",
	   CASE WHEN HSP_ACCT_CVG_LIST.LINE = 1 THEN 'Primary'
	        WHEN HSP_ACCT_CVG_LIST.LINE = 2 THEN 'Secondary'
		    ELSE 'No Coverage' END								"Filing Order"
  FROM HSP_ACCOUNT
    INNER JOIN HSP_ACCT_PAT_CSN
      ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_PAT_CSN.HSP_ACCOUNT_ID
    INNER JOIN PAT_ENC
      ON HSP_ACCT_PAT_CSN.PAT_ENC_CSN_ID = PAT_ENC.PAT_ENC_CSN_ID
    INNER JOIN PATIENT
      ON PAT_ENC.PAT_ID = PATIENT.PAT_ID
    INNER JOIN ACCOUNT
      ON HSP_ACCOUNT.GUARANTOR_ID = ACCOUNT.ACCOUNT_ID
    LEFT OUTER JOIN HSP_ACCT_CVG_LIST
      ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_CVG_LIST.HSP_ACCOUNT_ID
        AND HSP_ACCT_CVG_LIST.LINE <= 2
    LEFT OUTER JOIN V_COVERAGE_PAYOR_PLAN
      ON HSP_ACCT_CVG_LIST.COVERAGE_ID = V_COVERAGE_PAYOR_PLAN.COVERAGE_ID
  WHERE PAT_ENC.SERV_AREA_ID = 10
    AND PAT_ENC.CONTACT_DATE > DATEADD( YEAR, -1, CAST( CURRENT_TIMESTAMP AS DATE ) ) 
    AND PAT_ENC.CONTACT_DATE <= CURRENT_TIMESTAMP
    AND PAT_ENC.ENC_TYPE_C = '101'