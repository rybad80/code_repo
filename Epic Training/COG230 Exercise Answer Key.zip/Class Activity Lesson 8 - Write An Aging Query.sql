--� 2018 - 2022 Epic Systems Corporation. Confidential.

/*Using the basic syntax below, write an aging query based on the 
aging database object of your choice. Depending on the database object
you choose, you may need to make additional joins to get the proper
amount, age calculation, and/or grouping ID and name.

If you need inspiration, group your chosen database object by payor, 
filter to a date at the end of last year, and use aging categories 
of 0-90 days, 90-180 days, and 180+ days.
*/

USE Clarity_Aug

SELECT 'grouping ID'
	   MAX('grouping name')					'"group name"',
	   SUM(CASE WHEN 'age' >= 'lower bound' AND	'age' <= 'upper bound'
	            THEN 'amount' 
				ELSE 0 END) '�age category"'

  FROM 'table'
  WHERE 'aging date' = 'date'
  GROUP BY 'grouping ID'









	--Answer using V_ARHB_ATB_HAR_DETAIL
USE Clarity_Aug

SELECT PRIMARY_PAYER_ID,
       MAX( PRIMARY_PAYER_NAME )					"Payer",
       SUM( CASE WHEN DISCHARGE_DATE_AGE_BKT = '0 to 30' THEN ACTIVE_AR_BALANCE
       ELSE 0 END) "0 to 30",
       SUM( CASE WHEN DISCHARGE_DATE_AGE_BKT = '31 to 60' THEN ACTIVE_AR_BALANCE
       ELSE 0 END) "31 to 60"
  FROM V_ARHB_ATB_HAR_DETAIL
  WHERE AGING_DATE = '7/16/2020'
  GROUP BY PRIMARY_PAYER_ID
  ORDER BY MAX( PRIMARY_PAYER_NAME )