--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
You receive a report request to find out the ways billing office workers are resolving denials. 
- Show only resolved (completed) denials
- Display the date the denial was created, the date it was resolved, and the number 
of days the denial was open
- Include the billed amount and the denied amount
- Display the remittance code name, whether it was preventable, and how it was resolved
- Organize the report by payer and date created, with the latest dates first
*/

USE Clarity_Aug

SELECT CREATE_DATE				"Created Date",
	   RESOLVE_DATE				"Resolved Date",
	   OPEN_DAYS				"Open Days",
	   REMIT_CODE_NAME			"Remite Code",
	   PREVENTABLE_YN			"Preventable?",
	   RESOLVE_REASON			"Resolve Reason",
	   BILLED_AMT				"Billed Amount",
	   DENIED_AMT				"Denied Amount",
	   BUCKET_PAYOR_NAME		"Payer Name"
  FROM V_ARHB_BDC
  WHERE BDC_TYPE = 'Denial'
    AND DEN_RMK_CORR_STATUS = 'Completed'
  ORDER BY BUCKET_PAYOR_NAME,
           CREATE_DATE DESC