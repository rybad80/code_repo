--� 2018 - 2023 Epic Systems Corporation. Confidential.


/*Use Clarity to write a query that tracks the relationship between usage of patient estimates and HARs sent to bad debt in the year 2020. 
Display the number of Hospital Accounts currently in bad debt, the number of Hospital accounts currently in bad debt with an associated estimate, 
and the number of hospital accounts currently in bad debt without an estimate.�*/

USE Clarity_Aug;

WITH BAD_DEBT_ESTIMATE_CSN as (
	SELECT HSP_ACCOUNT.HSP_ACCOUNT_ID  'ID'
		  ,HSP_ACCT_PAT_CSN.PAT_ID
	FROM HSP_ACCOUNT
	  INNER JOIN HSP_ACCOUNT_3
		ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCOUNT_3.HSP_ACCOUNT_ID
      INNER JOIN HSP_ACCT_PAT_CSN
	    ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_PAT_CSN.HSP_ACCOUNT_ID
	  INNER JOIN PR_EST_PAT_CSN
		ON HSP_ACCT_PAT_CSN.PAT_ENC_CSN_ID = PR_EST_PAT_CSN.PATIENT_CSN
)

SELECT SUM( CASE WHEN BAD_DEBT_FLAG_YN = 'Y' THEN 1 ELSE 0 END )												"HARs in bad debt",
	   SUM( CASE WHEN BAD_DEBT_FLAG_YN = 'Y' AND BAD_DEBT_ESTIMATE_CSN.ID IS NOT NULL THEN 1 ELSE 0 END )		"HARs in bad debt with an estimate",
	   SUM( CASE WHEN BAD_DEBT_FLAG_YN = 'Y' AND BAD_DEBT_ESTIMATE_CSN.ID IS NULL THEN 1 ELSE 0 END )			"HARs in bad debt without an estimate"
  FROM HSP_ACCOUNT_3 
    LEFT OUTER JOIN BAD_DEBT_ESTIMATE_CSN 
      ON HSP_ACCOUNT_ID = BAD_DEBT_ESTIMATE_CSN.ID
  WHERE HSP_ACCOUNT_3.ZERO_BAL_ACTIVE_AR_DATE >= '1/1/2020'
    AND HSP_ACCOUNT_3.ZERO_BAL_ACTIVE_AR_DATE < '1/1/2021'

