--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Write a query to display all HARs in the EHS Service Area [10] with a 
primary payer of BCBS In State [200001]. Display the HAR�s ID, whether it is an HB or 
PB HAR, the guarantor�s current name, and the total balance on the HAR. 
Use either Clarity or Caboodle.
*/

USE Caboodle_Aug

SELECT BillingAccountFact.AccountEpicId			"HAR ID",
	   BillingAccountFact.BillingSystemType		"Hospital/Professional?",
	   GuarantorDim.Name						"Guarantor",
	   BillingAccountFact.TotalAccountBalance	"Total Balance"
  FROM BillingAccountFact
    INNER JOIN CoverageDim
      ON BillingAccountFact.PrimaryCoverageKey = CoverageDim.CoverageKey
    INNER JOIN GuarantorDim
      ON BillingAccountFact.GuarantorDurableKey = GuarantorDim.DurableKey
        AND GuarantorDim.IsCurrent = 1
    INNER JOIN DepartmentDim
      ON BillingAccountFact.DepartmentKey = DepartmentDim.DepartmentKey
  WHERE CoverageDim.PayorEpicId = '200001'
    AND DepartmentDim.ServiceAreaEpicId = '10'


USE Clarity_Aug

SELECT HSP_ACCOUNT.HSP_ACCOUNT_ID												"HAR ID",
	   /* Since every HAR in the EHS Service Area is an SBO HAR, this COALESCE doesn't change the results. 
		 It's still good practice for instructional purposes, since some service areas may not use SBO. */
	   COALESCE( ZC_SBO_HAR_TYPE.NAME, 'HB' )								"Hospital/Professional?",
	   ACCOUNT.ACCOUNT_NAME														"Guarantor",
	     /* Since every HAR in the EHS Service Area is an SBO HAR, this COALESCE doesn't change the results. 
		 It's still good practice for instructional purposes, since some service areas may not use SBO. */
	   COALESCE( HSP_ACCT_SBO.SBO_TOT_BALANCE, HSP_ACCOUNT.TOT_ACCT_BAL, 0 )	"Total Balance" 
  FROM HSP_ACCOUNT
    INNER JOIN ACCOUNT
      ON HSP_ACCOUNT.GUARANTOR_ID = ACCOUNT.ACCOUNT_ID 
	  /* Since every HAR in the EHS Service Area is an SBO HAR, the join to HSP_ACCT_SBO
	  and the join to ZC_SBO_HAR_TYPE could be INNER JOINs. LEFT OUTER JOINs are shown
	  here to demonstrate the SQL for working with both SBO and non-SBO service areas. */
    LEFT OUTER JOIN HSP_ACCT_SBO
      ON HSP_ACCOUNT.HSP_ACCOUNT_ID = HSP_ACCT_SBO.HSP_ACCOUNT_ID
    LEFT OUTER JOIN ZC_SBO_HAR_TYPE
      ON HSP_ACCT_SBO.SBO_HAR_TYPE_C = ZC_SBO_HAR_TYPE.SBO_HAR_TYPE_C
  WHERE HSP_ACCOUNT.PRIMARY_PAYOR_ID = 200001
    AND HSP_ACCOUNT.SERV_AREA_ID = 10


/*
Since the EHS Service Area uses SBO, the following SQL code is not needed for
this report request. It is included to demonstrate how to work with ARPB_VISITS
if you are reporting on any non-SBO service areas.
*/

/*
UNION ALL

SELECT ARPB_VISITS.PB_VISIT_ID,		
		'PB VISIT HAR',
		ACCOUNT.ACCOUNT_NAME,
		ARPB_VISITS.PB_TOTAL_BALANCE
  FROM ARPB_VISITS
	INNER JOIN ACCOUNT
	  ON ARPB_VISITS.GUARANTOR_ID = ACCOUNT.ACCOUNT_ID
	INNER JOIN COVERAGE
	  ON ARPB_VISITS.COVERAGE_ID = COVERAGE.COVERAGE_ID
  WHERE COVERAGE.PAYOR_ID = 200001
    AND ARPB_VISITS.SERV_AREA_ID = 10
*/

