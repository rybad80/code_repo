--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
A report request asks for all transactions generated through Resolute 
Professional Billing, grouped by bill area. The report should show 
separate columns for the active AR amount for the charges, payments, 
debit adjustments, and credit adjustments. Your coworker has started 
this query and has asked you to complete it.
*/

USE Clarity_Aug

SELECT MAX( BILL_AREA.RECORD_NAME )													"Bill Area",
       SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 1,10 ) THEN ACTIVE_AR_AMOUNT
	             ELSE 0 END )														"Charges",
       SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 2, 5, 11, 20, 22, 32, 33 )
	             THEN ACTIVE_AR_AMOUNT
				 ELSE 0 END )														"Payments",
       SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 3, 12 ) THEN ACTIVE_AR_AMOUNT
	             ELSE 0 END )														"Debit Adjustments",
       SUM( CASE WHEN CLARITY_TDL_TRAN.DETAIL_TYPE in ( 4, 6, 13, 21, 23, 30, 31 )
	             THEN ACTIVE_AR_AMOUNT
				 ELSE 0 END )														"Credit Adjustments",
       SUM( ACTIVE_AR_AMOUNT )														"Net"
  FROM CLARITY_TDL_TRAN
    LEFT OUTER JOIN BILL_AREA
      ON CLARITY_TDL_TRAN.BILL_AREA_ID = BILL_AREA.BILL_AREA_ID
  WHERE CLARITY_TDL_TRAN.DETAIL_TYPE < 40
    AND CLARITY_TDL_TRAN.POST_DATE > DATEADD( YYYY, -5, CURRENT_TIMESTAMP )
  GROUP BY CLARITY_TDL_TRAN.BILL_AREA_ID