--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your organization wants to know how much AR was held up in buckets 
with a balance of at least $25,000 at the end of April 2020. Group 
buckets by bucket-level financial class and payer. Age should be 
based on the discharge date for the hospital account. Display each payer's 
balance to show charges aged 0-90, 91-180, and greater than 180 days.
*/

USE Clarity_Aug

SELECT RESP_FINANCIAL_CLASS_NAME															"Financial Class",
	   MAX( RESP_PAYER_NAME )																"Payer",
	   SUM( CASE WHEN DISCHARGE_AGE <= 90 THEN TOTAL_BUCKET_BALANCE
	   	         ELSE 0 END )																"0-90",
	   SUM( CASE WHEN DISCHARGE_AGE > 90 AND DISCHARGE_AGE <= 180 THEN TOTAL_BUCKET_BALANCE
	   	         ELSE 0 END )																"91-180",
	   SUM( CASE WHEN DISCHARGE_AGE > 180 THEN TOTAL_BUCKET_BALANCE
	             ELSE 0 END )																"180 +"
  FROM V_ARHB_ATB_BUCKET_DETAIL
  WHERE TOTAL_BUCKET_BALANCE >= 25000 
    AND AGING_DATE = '30 April 2020'
  GROUP BY RESP_FINANCIAL_CLASS_NAME,
           RESP_PAYER_ID