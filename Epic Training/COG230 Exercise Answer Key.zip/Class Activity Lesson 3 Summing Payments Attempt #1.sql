--� 2018 - 2023 Epic Systems Corporation. Confidential.

USE Clarity_Aug

SELECT SUM( ARPB_TRANSACTIONS.AMOUNT )        "Original Payment Amount",
       BILL_AREA.RECORD_NAME                  "Bill Area"
  FROM ARPB_TRANSACTIONS
    LEFT OUTER JOIN BILL_AREA
      ON ARPB_TRANSACTIONS.BILL_AREA_ID = BILL_AREA.BILL_AREA_ID
  WHERE ARPB_TRANSACTIONS.TX_TYPE_C = '2'
  GROUP BY BILL_AREA.RECORD_NAME

USE Caboodle_Aug

SELECT SUM( BillingTransactionFact.PaymentAmount )           "Original Payment Amount",
       BillAreaDim.BillAreaName                               "Bill Area"
  FROM BillingTransactionFact
  	INNER JOIN BillAreaDim
      ON BillingTransactionFact.BillAreaKey = BillAreaDim.BillAreaKey
  WHERE BillingTransactionFact.TransactionType = 'Payment'
    AND BillingSystemType = 'Professional'
  GROUP BY BillAreaName