--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Your insurance follow-up supervisor wants to identify how many PB denials have been received for 
coding reasons (denial class).
- Display the date that each denial was received
- For each denial, display the remittance code, the billed amount, and the denied amount
- Filter to just coding denials (denial class)
- The report should be organized by payer and then by amount billed, with the 
greatest amounts first
*/

USE Clarity_Aug

SELECT CLARITY_EPM.PAYOR_NAME					"Payer Name"	 
	,BDC_INFO.BDC_RECEIVE_DATE					"Received Date"
	,CLARITY_RMC.REMIT_CODE_NAME				"Remittance Code"
	,HSP_BDC_DENIAL_DATA.LINE_BILLED_AMOUNT		"Billed Amount"
	,HSP_BDC_DENIAL_DATA.LINE_DENIED_AMT		"Denied Amount"
  FROM BDC_INFO
    INNER JOIN HSP_BDC_DENIAL_DATA
      ON BDC_INFO.BDC_ID = HSP_BDC_DENIAL_DATA.BDC_ID
      -- Join for payer name
    INNER JOIN ARPB_TRANSACTIONS
      ON BDC_INFO.SOURCE_PMT_PB_TX_ID = ARPB_TRANSACTIONS.TX_ID
    INNER JOIN CLARITY_EPM
      ON ARPB_TRANSACTIONS.PAYOR_ID = CLARITY_EPM.PAYOR_ID
      -- Join for remittance code
    INNER JOIN CLARITY_RMC
      ON BDC_INFO.REMIT_CODE_ID = CLARITY_RMC.REMIT_CODE_ID
      -- Join for denial category
    INNER JOIN 	ZC_DENIAL_CLASS
      ON BDC_INFO.DENIAL_CLASS_C = ZC_DENIAL_CLASS.DENIAL_CLASS_C
  WHERE BDC_INFO.BILLING_SYS_C = 1
    AND ZC_DENIAL_CLASS.NAME = 'Coding'
  ORDER BY CLARITY_EPM.PAYOR_NAME,
           HSP_BDC_DENIAL_DATA.LINE_BILLED_AMOUNT DESC