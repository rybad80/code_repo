--� 2018 - 2023 Epic Systems Corporation. Confidential.

/*
Use either Caboodle or Clarity to write a query to find the 
number of PB transaction details for each HAR. Display the 
HAR's ID and billing status.
*/

USE Caboodle_Aug

SELECT BillingAccountFact.AccountEpicId		"HAR ID",
	   BillingAccountFact.BillStatus		"Billing Status",
	   COUNT(BillingTransactionFact.Count)	"Number of Transaction Details"
  FROM BillingTransactionFact
    INNER JOIN BillingAccountFact
      ON BillingTransactionFact.BillingAccountKey = BillingAccountFact.BillingAccountKey
  WHERE BillingTransactionFact.BillingSystemType = 'Professional'
  GROUP BY BillingAccountFact.AccountEpicId,
           BillingAccountFact.BillStatus

USE Clarity_Aug

SELECT MAX( HSP_ACCOUNT.HSP_ACCOUNT_ID )			"HAR ID",
	   MAX( ARPB_VISITS.PB_VISIT_ID )				"VFO HAR ID",
	   MAX( COALESCE( HBSTAT.NAME,PBSTAT.NAME ) )	"Billing Status",
	   COUNT (CLARITY_TDL_TRAN.TDL_ID )				"Number of Transaction Details"
  FROM CLARITY_TDL_TRAN
    LEFT OUTER JOIN HSP_ACCOUNT
      ON CLARITY_TDL_TRAN.HSP_ACCOUNT_ID = HSP_ACCOUNT.HSP_ACCOUNT_ID
    LEFT OUTER JOIN ARPB_VISITS
      ON CLARITY_TDL_TRAN.HSP_ACCOUNT_ID = ARPB_VISITS.PB_VISIT_ID
    LEFT OUTER JOIN ZC_ACCT_BILLSTS_HA HbStat
      ON HSP_ACCOUNT.ACCT_BILLSTS_HA_C = Hbstat.ACCT_BILLSTS_HA_C
    LEFT OUTER JOIN ZC_ACCT_BILLSTS_HA PbStat
      ON ARPB_VISITS.PB_BILLING_STATUS_C = pbstat.ACCT_BILLSTS_HA_C
  WHERE HSP_ACCOUNT.HSP_ACCOUNT_ID IS NOT NULL 
    OR ARPB_VISITS.PB_VISIT_ID IS NOT NULL
  GROUP BY CLARITY_TDL_TRAN.HSP_ACCOUNT_ID,
           COALESCE( HBSTAT.NAME, PBSTAT.NAME )