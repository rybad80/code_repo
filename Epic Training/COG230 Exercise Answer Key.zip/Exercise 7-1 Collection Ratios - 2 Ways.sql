--� 2018 - 2023 Epic Systems Corporation. Confidential.

--Query #1: 

USE Clarity_Aug

SELECT MAX( ZC_CUR_FIN_CLASS.NAME )		   "Financial Class",
	   AVG( NET_COLL_RATIO )               "Average Net Collection Ratio"
  FROM ARPB_TX_COLL_RATIO
    INNER JOIN ARPB_TRANSACTIONS
      ON ARPB_TX_COLL_RATIO.TX_ID = ARPB_TRANSACTIONS.TX_ID
    INNER JOIN ZC_CUR_FIN_CLASS
      ON ARPB_TRANSACTIONS.ORIGINAL_FC_C = ZC_CUR_FIN_CLASS.CUR_FIN_CLASS
  GROUP BY ZC_CUR_FIN_CLASS.CUR_FIN_CLASS
  HAVING AVG( NET_COLL_RATIO ) IS NOT NULL
  ORDER BY "Financial Class"


--Query #2: 

USE Clarity_Aug

SELECT MAX( ZC_CUR_FIN_CLASS.NAME )																		   "Financial Class",
	   SUM( ARPB_TX_COLL_RATIO.ACTUAL_AR_COLLECTIONS ) / SUM( ARPB_TX_COLL_RATIO.EXPECTED_AR_COLLECTIONS ) "Net Collection Ratio"
  FROM ARPB_TX_COLL_RATIO
     INNER JOIN ARPB_TRANSACTIONS
      ON ARPB_TX_COLL_RATIO.TX_ID = ARPB_TRANSACTIONS.TX_ID
     INNER JOIN ZC_CUR_FIN_CLASS
      ON ARPB_TRANSACTIONS.ORIGINAL_FC_C = ZC_CUR_FIN_CLASS.CUR_FIN_CLASS
  GROUP BY ZC_CUR_FIN_CLASS.CUR_FIN_CLASS
  HAVING ( SUM( ARPB_TX_COLL_RATIO.ACTUAL_AR_COLLECTIONS ) / SUM( ARPB_TX_COLL_RATIO.EXPECTED_AR_COLLECTIONS ) ) IS NOT NULL 
	--HAVING is a technique covered in the SQL II self-study that allows us to filter out entire groups from our results rather than individual rows from our groups.
	--Understanding HAVING is not critical to this exercise - it's there to make the results easier to read. 
  ORDER BY "Financial Class"