--� 2018 - 2023 Epic Systems Corporation. Confidential.

--Note: This exercise practices skills and concepts that are from a Beyond the Basics section of this companion. Those skills and concepts will not be tested.


/*Your organization wants you to find the top reasons, by remit category and code, 
that Professional Billing charges are getting denied. Find all PB denials, grouped by 
remit category (or denial class) and remit code. Find all combinations with greater 
than 100 denials, and display the number of denials and the total amount denied. 
Order by number of denials, with the greatest number first.
*/

--Note: Due to the conversion from the older PB denials recording system and BDC records, the
-- below solutions contain additional joins and filters for filtering on the service date.
--This brings the record counts of both queries closer to each other, but likely not exactly the same.

USE Clarity_Aug

SELECT MAX( ZC_DENIAL_CLASS.NAME )					"Denial Class",
       MAX( CLARITY_RMC.REMIT_CODE_NAME )			"Remit Code",
       COUNT( * )									"Count of Denials",
       SUM( HSP_BDC_DENIAL_DATA.LINE_DENIED_AMT )	"Amount Denied"
  FROM BDC_INFO
    INNER JOIN CLARITY_RMC
      ON BDC_INFO.REMIT_CODE_ID = CLARITY_RMC.REMIT_CODE_ID
    INNER JOIN ZC_DENIAL_CLASS
      ON BDC_INFO.DENIAL_CLASS_C = ZC_DENIAL_CLASS.DENIAL_CLASS_C
      --join for service date
    INNER JOIN HSP_BDC_DENIAL_DATA
      ON BDC_INFO.BDC_ID = HSP_BDC_DENIAL_DATA.BDC_ID
    -- PB denials
  WHERE	BDC_INFO. BILLING_SYS_C = 1
  	AND HSP_BDC_DENIAL_DATA.LINE_SERVICE_DATE > '1/1/2019'
  GROUP BY BDC_INFO.DENIAL_CLASS_C,
           CLARITY_RMC.REMIT_CODE_ID
  HAVING COUNT( * ) > 100
  ORDER BY COUNT( * ) DESC


--without using BDC records (record counts between queries may differ)
USE Clarity_Aug

SELECT MAX( ZC_DENIAL_CLASS.NAME )				"Denial Class",
       V_ARPB_REMIT_CODES.REMIT_CODE_NM_WID		"Remit Code",
       COUNT( * )								"Number of Denials",
       SUM( V_ARPB_REMIT_CODES.REMIT_AMOUNT )	"Amount Denied"
  FROM V_ARPB_REMIT_CODES
    INNER JOIN CLARITY_RMC
      ON V_ARPB_REMIT_CODES.REMIT_CODE_ID = CLARITY_RMC.REMIT_CODE_ID
    INNER JOIN ZC_DENIAL_CLASS
      ON CLARITY_RMC.DENIAL_CLASS_C = ZC_DENIAL_CLASS.DENIAL_CLASS_C
    -- denials
  WHERE V_ARPB_REMIT_CODES.REMIT_ACTION = 9  
    AND V_ARPB_REMIT_CODES.SERVICE_DATE > '1/1/2019'
  GROUP BY CLARITY_RMC.DENIAL_CLASS_C,
           V_ARPB_REMIT_CODES.REMIT_CODE_NM_WID
  HAVING COUNT( * ) > 100
  ORDER BY COUNT( * ) DESC